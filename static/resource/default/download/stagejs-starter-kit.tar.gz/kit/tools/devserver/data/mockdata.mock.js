module.exports = {
		'items|5': [{
			'id': '@FIRST',
			'ip': '@IP'
		}],
	};