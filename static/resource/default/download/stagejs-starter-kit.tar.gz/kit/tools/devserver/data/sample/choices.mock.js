//mockjs template (https://github.com/nuysoft/Mock/wiki/Syntax-Specification)
module.exports = {
	'payload|10-10': [{
		label: '@EMAIL',
		value: '@label'
	}]
};