Stage.js
========
Released without theme src and build tools. Use the *project-kit* if want to start building large production project with more libraries, multiple customized themes and intuitive dev tools.

Please go to our project site for more info [Stage.js](http://bluekvirus.github.io/Stage.js/)