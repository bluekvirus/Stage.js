Stage.js
========
Released with simplified sample project structure. Use the *Starter-Kit* version of **Stage.js** if want to build large production project with more libraries and multiple customized themes.

Please go to our project site for more info [Stage.js](http://bluekvirus.github.io/Client_/)