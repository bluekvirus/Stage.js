/**
 * This is the Resources meta objects, it doesn't have actual data, but it utilizes
 * model objects under /models to provide logic apis as service.
 *
 * It is similar as the 'Controller' concept in traditional MVC, but since we don't have
 * C and V here, everything should be an M like a Java Bean. To distinguish it with real
 * model object, we call it the meta object.
 *
 * Resources 
 * 1. list - list registered resources (models) for privilege editor in Role.
 *
 * [use me instead of my when define]
 * @author Tim.Liu
 * @created 2013.06.15
 */

var _ = require('underscore');

module.exports = function(app){

	var me = {
		meta: {
			name: 'Resources',
			type: 'meta', //otherwise it's table/complex or single/multi
		},
		restriction: {
            logic: { //exposed methods(static/instance)
            }
		}
	};

	/**
	 * ============logics===============
	 */
	
	/**
	 * List the registered Entities (models, meta objects) each
	 * with registered named routes under 'general'.
	 *
	 * Model:
	 * 	data:
	 * 		std
	 * 		ref [per ref field]
	 * 	file:
	 * 		std
	 * 	logic:
	 * 		std [per exposed method]
	 *
	 * Meta Obj:
	 * 	logic:
	 * 		std [per exposed method]
	 * 
	 * [For privilege map in resource-control editor]	
	 * 	
	 */

	 app.expose(me, 'list', function(options, cb){

	 	var routesPerEntity = app.util.namedroutes.get('general');

	 	//check user's account space:
	 	if(options.user)
	 		var userspacelvl = app.config.spaceScale[options.user.space] || 0;
	 	//1 models
	 	var modelNames = _.keys(app.util.modelmap.getMap());
	 	//we will exclude the core models if the user is below space lvl: System.
	 	if(options.user && userspacelvl < app.config.spaceScale['System'])
	 		modelNames = _.without(modelNames, 'Role');

	 	var modelsPList = _.compact(modelNames.map(function(m){

	 		var def = app.getModelDef(m);
	 		if(def.meta.enhance) return null; //skip enhancement models.

	 		//listing tpl
	 		var list = {
	 			name: m,
	 			routes: {
	 				data: {
	 					std: routesPerEntity.data.std,
	 					ref: {},
	 				},
	 				file: {},
	 				logic: {},
	 			}
	 		};

	 		//populate the ref routes per ref field
	 		_.each(def.meta.ref, function(refInfo, refField){
	 			if(!refInfo.oneToOne) //remove the one-to-one ref field, these are model data enhancements that should be treated as a whole with parent record data.
	 				list.routes.data.ref[refField] = routesPerEntity.data.ref;
	 		});

	 		//populate the file routes per file field
	 		_.each(def.restriction.file, function(fRestrict, fField){
	 			list.routes.file[fField] = routesPerEntity.file.std;
	 		});

	 		//populate the logic routes per method - a bit detailed handling here...
	 		_.each(def.restriction.logic, function(type, mName){
	 			type = (type==='static'?0:1);
	 			list.routes.logic[mName] = {
	 				exec: {
		 				token: routesPerEntity.logic.std.exec.token,
		 				data: [routesPerEntity.logic.std.exec.data[type]],
	 				}
	 			};
	 		});

	 		return list;
	 	}));

	 	//2 meta objects
	 	var metaObjNames = _.keys(app.util.metaobjmap.getMap());
	 	//we will exclued the Resource meta object if the user is blow space lvl: System.
	 	if(options.user && userspacelvl < app.config.spaceScale['System'])
	 		metaObjNames = _.without(metaObjNames, 'Resources');

	 	var metaobjList = metaObjNames.map(function(m){
	 		return {
	 			name: m,
	 			token: routesPerEntity.logic.std.exec.token, //using the same token name that data objects use for logic.
	 			methods: app.getMetaObj(m).restriction.logic,
	 		}
	 	})

	 	var result = {
	 		models: modelsPList,
	 		metaobjs: metaobjList,
	 	};

	 	cb(null, result);
	 
	 });

	/**
	 * ============Register=============
	 */
	app.util.metaobjmap.register(this.location, me.meta.name);
	return me;

}