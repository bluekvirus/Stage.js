/**
 * =======================================
 * Mongo ORM model loading issue resolver.
 * =======================================
 *
 * It is designed to be used with the directory loading tool like 'express-load'. When
 * a model can not be loaded because of its dependencies are missing, the resolver will
 * be notified and have the [dep], [waiting] lists record this incident, later, if there are
 * still models waiting to be loaded in the waiting list, the loading sequence will continue.
 *
 *
 * When a dep incident occurs:
 * 	problem: A needs B, C, D....
 * 	steps:
 * 		1. check if A is in the dep list -> YES: move A down to the 1st spot in the waiting list, 
 * 												(someone put A up, move it down and before all possible 'someone')
 * 										 -> NO: append A to the tail of waiting list;
 * 		2. check if B/C/D is in either of the dep, waiting lists -> YES: do nothing,
 * 																 -> NO: append B/C/D to the tail of dep list;
 * 	    3. intersect dep and waiting list, check if there is a model name which appears in both lists -> YES: Report circle!!
 * 	    																							  -> NO: do nothing
 *
 * Start:
 * 	Initially, the waiting list are populated by first round 'express-load'; (model def has try/catch block for Schema def);
 *
 * Loop:
 * 	After 1st round loading, we loop till the waiting list becomes empty.
 *
 * Report:
 * 	Link the model loading incident through the app object. So this object needs to be spiced with a report function and two arrays 
 * 	in the closure to represent the loop states.
 * 	
 * 	
 * Circle:
 * 	This happens when there is a model appears in both list after we process the incident report.
 *  This should break the loading sequence and get reported to developer.
 *  
 *  
 * Note:
 * 	Each round should start with the dep list emptied since the models on this level of dep tree
 * 	have already been loaded.
 *
 * @author Tim.Liu
 * @created 2013.05.23
 */

var _ = require('underscore'),
	path = require('path'),
	load = require('express-load');

module.exports = function(app){

	var depQ = [], waitQ = [];

	var moveToWaitQ = function(target, depTargets){
		//default on moving to first element of waitQ
		//and have all its dep targets push to depQ.
		depQ = _.without(depQ, target);
		waitQ.unshift(target);
		_.each(depTargets, function(depTarget){
			if(!isIn(depQ, depTarget))
				depQ.push(depTarget);
		});
	};

	var isIn = function(q, target){
		//target can be string (q is depQ) or object (q is waitQ)
		return _.contains(q, target);
		
	};

	var round = 1;

	var me = {
		report: function(reporter, depTargets){

			console.log('Unsuccessful Load:', reporter, ' needs ', depTargets);
			//use .dot notation.
			reporter = reporter.split(path.sep).join('.');

			//check 1
			if(isIn(depQ, reporter)){
				moveToWaitQ(reporter, depTargets);
			}else {
				waitQ.push(reporter);
			}

			//check 2
			_.each(depTargets, function(depTarget){
				if(isIn(depQ, depTarget) || isIn(waitQ, depTarget)){
					;
				}else {
					depQ.push(depTarget);
				}
			});

			//check 3
			var knot = _.intersection(depQ, waitQ);
			if(!_.isEmpty(knot)) {
				var msg = 'Circle Detected: -->' + knot + ' -->';
				throw new Error(msg);
			}
			
		},

		isDone: function(){
			var result = _.isEmpty(waitQ);
			return result;
		},

		resolve: function(){
			if(this.isDone() || round > 5) return;

			console.log('Resolve Round: ', round++);

			depQ = []; //get ready for next round of load...
			waitQCopy = _.clone(waitQ);
			waitQ = [];
			while(!_.isEmpty(waitQCopy)){
				var targetToLoad = waitQCopy.shift().split('.').join(path.sep)+'.js';
				load(targetToLoad, {verbose:true}).into(app);	
			}
			this.resolve();
		}
	};

	return me;

}

