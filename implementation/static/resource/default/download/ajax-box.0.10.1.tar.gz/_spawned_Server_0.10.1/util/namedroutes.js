/**
 * This is the route registry utility that helps create routes with names.
 * These names are checked later with req.user's privilege map when the registered
 * route gets activated. If the name is contained in the privilege map, the route gets
 * though.
 *
 * Only named routes registered with this util object will be checked in the authorization filter (/routes/filters.js).
 *
 * -----------
 * Deep Assign
 * -----------
 * We use TOKEN and DATA in deep-assign registery (route group reg) to represent each route group entry.
 * Token is the full dotPath (route group name) with '.' replaced by '_' since there can't be '.'/'$' in data field keys (like in a mixed object)
 * 
 *
 * @author Tim.Liu
 * @created 2013.06.16
 */

var _ = require('underscore');

/**
 * -------------------
 * Private Func Helper
 * -------------------
 * Assign value into object using a .dot path. val on same name gets Qed.
 * @param  {[type]} dotPath [description] -> token
 * @param  {[type]} host    [description]
 * @return {[type]}         [description]
 */
function deepAssign(dotPath, val, host){
	var path = dotPath.split('.');
	while(path.length > 1){
		var mid = path.shift();
		host[mid] = host[mid] || {};
		host = host[mid];
	}
	var slot = path.shift();
	if(!host[slot]) host[slot] = {token: dotPath.replace(/\./g, '_'), data: []};
	host[slot].data.push(val);

}
/**
 * -------------------
 * Private Func Helper
 * -------------------
 * Dive into a fetch a dotPath noted object from host.
 * @param  {[type]} dotPath [description]
 * @param  {[type]} host    [description]
 * @return {[type]}         [description]
 */
function dive(dotPath, host){
	if(!dotPath) return;

	dotPath = dotPath.split('.');
	while(dotPath.length > 0){
		host = host[dotPath.shift()];
	}

	return host;
}

module.exports = function(app){

	var util = {
		registry: {},
	};

	/**
	 * Replaces the standard route declaration method.
	 * @param  {[type]} name       this can be dotted name, for grouping purposes.
	 * @param  {[type]} httpmethod get/put/post/delete/all
	 * @param  {[type]} callbacks  [,callbacks], callback array.
	 * @return {[type]}            [description]
	 */
	util.register = app.serve = function(name, httpmethod, path, callbacks){
		
		deepAssign(name, {
			url: httpmethod.toUpperCase() + ' ' + path
		}, util.registry);

		app[httpmethod](path, function(req, res, next){
			req.routeGroup = name.replace(/\./g, '_');//token ready to be examined (authorization)
			next();
		}, [].slice.call(arguments, 3));
	}

	/**
	 * Look up the registered route/routes group.
	 * @param  {[type]} dotPath [description]
	 * @return {[type]}         [description]
	 */
	util.get = function(dotPath){
		return dive(dotPath, util.registry);
	}

	return util;

}