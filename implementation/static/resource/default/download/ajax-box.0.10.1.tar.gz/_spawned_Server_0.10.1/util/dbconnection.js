/**
 * 
 */

var mongoose = require('mongoose')
  , url = require('url');

module.exports = function(app){

	var util = {};

	util.getURL = function(dbType){
		switch(dbType){
			case 'mongodb':
				return 'mongodb:' + url.format({
					hostname: app.config.database.mongodb.host,
					port: app.config.database.mongodb.port,
					auth: (app.config.database.mongodb.password && (app.config.database.mongodb.username + ':' + app.config.database.mongodb.password)) || '',
					pathname: app.config.database.mongodb.name
				});

			case 'mysql':
				break;

			case 'redis':
				break;
		}
	}

	util.connect = function(dbType){
		switch(dbType){
			case 'mongodb':
				var con = mongoose.createConnection(util.getURL(dbType));
				con.on('error', function(){
					console.error('connection error: ', arguments);
				})
				return con;
				break;

			case 'mysql':
				break;

			case 'redis':
				break;

		}
	}

	return util;

}