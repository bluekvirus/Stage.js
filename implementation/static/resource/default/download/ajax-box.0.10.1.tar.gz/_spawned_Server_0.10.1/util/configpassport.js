/**
 * As the name suggests... This is where we find the default Super Admin user as well. 
 *
 * Note that the Super Admin User is system wise, and has NO ROLES and is named 'admin' ... see routes/filters.js auth
 */
var passport = require('passport'),
_ = require('underscore'),
colors = require('colors');

module.exports = function(app){

	return {

		setup: function(){
			//config passport auth middleware
			var User = app.getModel('User');
		    passport.use(User.createStrategy());
		    passport.serializeUser(User.serializeUser());
		    passport.deserializeUser(User.deserializeUser());

			//Preset User Accounts
			//Note that since the super admin has been given the 'System' account space, everything it creates will be in the Administrator space (always -1 lvl), thus can be further managed by real admin users.   
		  	var q = User.remove({username: {$in: _.keys(app.config.server.users)}});
		  	q.exec().then(function(){
		  		User.create(_.map(app.config.server.users, function(user, name){
		  			return {
		  				username: name,
		  				password: user.password,
		  				account_space: user.account_space,
		  				_space: app.config.spaceScale[user._space],
		  				roles: user.roles || []
		  			};
		  		}), function(err){
		  			if(err) console.log('Can NOT create preset users:', err.message.red);
		  			else {
		  				var users = _.toArray(arguments).slice(1);
			    		console.log('Preset users created...'.yellow, _.pluck(users, 'username'));
			    	}
		  		});
		  	});
		},

		getInstance: function(){
			return passport;
		}
	}
}