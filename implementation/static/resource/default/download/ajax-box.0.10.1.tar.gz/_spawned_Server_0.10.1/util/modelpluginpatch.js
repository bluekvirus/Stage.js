/**
 *
 * Patch the model plugins:
 * [3 types of plugins]
 * 	Auto - use models/_plugins/auto-patch, this applies to all models.
 * 	Selective - use models/_plugins/selective-patch, this only applies to selected models. 
 *
 * This is used in model wake up call - in util/modelmap.js atm.
 *
 * @author Tim.Liu
 * @created 2013.06.03
 */

var _ = require('underscore');

module.exports = function(app){

	/**
	 * [ description]
	 * @param  {[type]} definition This is the model module definition.
	 * @return {[type]}            [description]
	 */
	return function(definition){
		//1 Auto
		_.each(app.models.Plugins.autoPatch, function(plug, name){
			//console.log(plug, name, '->', definition.meta.name);
			definition.Schema.plugin(plug, {definition:definition});
		});
		

		//2 Selective
		//Not used atm...
		var ext = app.models.Plugins.selectivePatch[definition.meta.name + 'Ext'];
		if(ext){
			definition.Schema.plugin(ext, {definition:definition});
		}
	}

};