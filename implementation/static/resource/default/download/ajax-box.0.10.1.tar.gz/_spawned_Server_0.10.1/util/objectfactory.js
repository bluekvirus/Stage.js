/**
 * This is the meta/model object factory, it helps generate meta/model object definition at runtime.
 *
 * =======
 * Design
 * =======
 * Like the front-end Admin Module Factory, this factory helps control a general code def template for the server side model and meta objects.
 * This will make patching/extending the model/meta object much easier since the base code tpl do not need to be in a separate file.
 * 	e.g the model def file can be a one line-er with extension code directly put into it. the _plugins/selective should no longer be needed...
 *
 *
 * ======
 * Usage
 * ======
 * app.util.objectfactory.create(name, [meta/...(default on model)], options);
 *
 * =======
 * Plus
 * =======
 * options.schema will be pre-processed, you can use 
 *  sub: ['model name'] - note that you are not allowed to use (sub: 'model name') atm, it will crash the model.
 *  ref: ['model name'] or 'model name'
 * for sub/ref doc field definition short-cut respectively see - _preprocessSchema() down below.
 *
 * =======
 * Options
 * =======
 * See per model/meta object tpl down at the bottom.
 *
 * @author Tim.Liu
 * @created 2013.09.30
 */
var mongoose = require('mongoose'),
    _ = require('underscore');

module.exports = function(app){

	return {
		create: function(name, type, options){
			if(!options) {
				options = type;
				type = 'Mongo.Model'; //this can be whatever atm...
			}
			switch(type){
				case 'meta':
					return createMeta(app, name, options);
				default:
					return createModel(app, name, options);
			}
		}
	}

};


/*--------------Model Tpl--------------*/
//Options:
//	[idAttribute]
//	*schema
//	*srcLocation - pass in this.location so we can send report to model-load-resolver to load this src file later.
function createModel(app, name, options){
    /**
     * ================================================
     * 0. Metadata, Restriction
     * 
     * data: field validation rules,
     * file: file upload type, number and size limits,
     * logic: exposed method names from model schema,
     * ================================================
     */

    var my = {
        meta: {
            name: name,
            keyField: options.idAttribute || '_id',
            mutex: options.mutex || 'read-only', //mutual-exclusion on record update/deletion within the same role in 'User' space, see - auto-patch/mutex.js
            imposeOwnerSpace: options.imposeOwnerSpace || false, //true/false, whether or not to impose the creator's account space as the record's space. false means to use the 'User' space.
        },
        restriction: {
            data: {
                //field validations
            },
            file: {
                //file number size limitations
            },
            logic: { 
                //exposed methods(static/instance)
            }

        }
    };


    /**
     * ==============================
     * 1. Schema Definition & Options
     * ==============================
     */
    try {
    	_preprocessSchema(app, my.meta, options.schema, my.restriction);
    } catch (e) {
        if (/'Schema' of undefined/.test(e.toString())) { //Report this to app.
            app.util.modelloadresolver.report(options.srcLocation, my.meta.sub);
            return;
        }else
         console.log('DEV::BUG::', e);
    }
    try {
        my.Schema = mongoose.Schema(options.schema, {
            /**
    	     * =====================
    	     * Schema Options
    	     * =====================
    	     * Transform hidden fields can be overriden in [Model Name].ext.js
    	     * e.g:
    	     * 	extSchema.set('hideInJSON', ['hash', 'salt']);
             *  extSchema.set('toObject', ['hash', 'salt']);
    	     */
            toObject: {
                transform: function(doc, ret, options) {
                    doc.schema.eachPath(function(key, val) {
                        if (val.options.hideInObject) delete ret[key];
                    });
                    /**
                     * Can be overriden in [Model Name].ext.js
                     */
                    _.each(doc.schema.options.hideInObject, function(key) {
                        delete ret[key];
                    });
                }
            },
            toJSON: {
                transform: function(doc, ret, options) {
                    doc.schema.eachPath(function(key, val) {
                        if (val.options.hideInJSON) delete ret[key];
                    });
                    /**
                     * Can be overriden in [Model Name].ext.js
                     */
                    _.each(doc.schema.options.hideInJSON, function(key) {
                        delete ret[key];
                    });
                }
            },
            versionKey: false //remove __v
        });
    } catch(e){
        my.Schema = undefined;
    }

    /**
     * =====================================
     * 2. Schema Plus and Additional Options
     *
     * Leave uncommon ones in [Model Name].ext.js
     * =====================================
     */

    /**
     * ==================================================
     * 3. Pre/Post save hooks
     * 	- validation
     * 	- file limitation (in file upload middleware atm)
     * 	- field manipulate (in separate file)
     * 	- transaction hook/trigger (in separate file)
     *
     * Leave uncommon ones in [Model Name].ext.js
     * ==================================================
     */

    /**
     * ====================================================
     * 4. Class Statics/Instance Methods
     *
     * Leave uncommon ones in [Model Name].ext.js
     * ====================================================
     */

    /**
     * ==================[Model Name].ext.js==================
     * Put under /models/_plugins/selective-patch/
     * ===================================================
     */

    //Schema Registration
    app.util.modelmap.register(options.srcLocation, name); //my.Schema will be compiled later into my.Model
    return my;
}

function _preprocessSchema(app, metadata, schema, restriction){
	//find ref or sub doc models, since we allow shortcut notation for ref and sub doc types
    //also we find the file field which shouldn't be stored in DB, and init its constrain block in the model's metadata section.
	_.each(schema, function(field, key){
		if(!field.type){
			if(field.ref) {
				var ref = field.ref;
				delete field.ref;
				if (_.isArray(ref)){
					var collection = true;
					ref = ref.pop();
				}
				ref = { //change ref: ... to formal MongooseJS Schema type
	                type: mongoose.Schema.Types.ObjectId,
	                ref: ref
	            }
				if(collection)
					schema[key] = [ref];
	            else
	            	schema[key] = ref;
			}else if(field.sub) {
				metadata.sub = metadata.sub || {};
				var sub = field.sub;
				delete field.sub;
				if(_.isArray(sub)){
					var collection = true;
					sub = sub.pop();
				}
				metadata.sub[key] = {model: sub};
				sub = app.getModelDef(sub).Schema; //find sub: ... required MongooseJS Schema type

				if(collection)
					schema[key] = [sub];
				else
					schema[key] = sub;
			}
		}else if(field.type === '__File'){
            restriction.file[key] = {
                enabled: true,
                types: [], //this is used as a acceptance list, different than the file upload middleware's.
                size: {
                    min: 1, //in Bytes
                    max: 0,
                    total: 0 //total size allowed per record.
                },
                number: 0 //total number of files allowed per record.
            };
            delete schema[key];
        }
	});
}



/*--------------Meta Object Tpl--------------*/

function createMeta(app, name, options){

}