/**
 * This is the model map/registry for app to wake up 
 * model definitions at runtime.
 *
 * -----------------
 * Short-Cut Exposed
 * app.getModel('compiled model name');
 * -----------------
 *
 * @author Tim.Liu
 * @created 2013.06.02
 */

var path = require('path'),
	_ = require('underscore'),
	colors = require('colors');

/**
 * -------------------
 * Private Func Helper
 * -------------------
 * Dive into a fetch a dotPath noted object from host.
 * @param  {[type]} dotPath [description]
 * @param  {[type]} host    [description]
 * @return {[type]}         [description]
 */
function dive(dotPath, host){
	if(!dotPath) return;

	dotPath = dotPath.split('.');
	while(dotPath.length > 0){
		host = host[dotPath.shift()];
	}

	return host;
}

function toCamString(name){
	return name.split(/[^a-zA-Z0-9]/).map(function(sub, i){
				if(i === 0) return sub;
				return sub.charAt(0).toUpperCase() + sub.substr(1);
			}).join('');
}

/**
 * ---------------
 * Util Definition
 * ---------------
 * @param  {[type]} app [description]
 * @return {[type]}     [description]
 */
module.exports = function(app){

	var reg = {
		map : {},
	};


	reg.register = function(location, name){
		reg.map[name] = location.split(path.sep).map(function(part){
			return toCamString(part);
		}).join('.');
	};

	//Just for mongodb atm...
	reg.wakeup = function(db){
		//round ZERO:
		_.each(reg.map, function(srcRef, modelName){
			if(!reg.getDef(modelName).Schema){
				delete reg.map[modelName];
				console.log(('- Removed Broken Model:' + modelName).red, '[see -', srcRef, ']');
			}else
				console.log(('+ Model Loaded:' + modelName).green);
		});
		//round A:
		reg.each(function(definition){
			//sort out relations (taking notes in metadata block)
			app.util.modelrelationship.link(definition);
		});
		//round B:
		reg.each(function(definition){
			//apply plugins
			app.util.modelpluginpatch(definition);

			try{
				definition.Model = db.model(definition.meta.name, definition.Schema);
			}catch(e){
				console.log('[ERROR - ' + definition.meta.name + ']', e);
			}
		});
	};

	/**
	 * Get **Compiled** Model. - .Model
	 */
	reg.get = app.getModel = function(name){
		return dive(reg.map[name], app).Model;
	};

	/**
	 * Get **Uncompiled** model module def.
	 */
	reg.getDef = app.getModelDef = function(name){
		return dive(reg.map[name], app);
	};
	

	reg.getMap = function(){
		return reg.map;
	};

	/**
	 * Development only...
	 * @param  {[type]} apply [description]
	 * @return {[type]}       [description]
	 */
	reg.each = function(apply){
		_.each(reg.map, function(modelLoadPath, name){
			apply(reg.getDef(name));
		});
	}

	return reg;

};