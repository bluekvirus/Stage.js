/**
 * Same as modlemap, only this time it is a registry for meta_objects.
 * 
 * 
 * Consider:
 * This kinda structure allows meta objects to be loaded under a sub-folder like data models. 
 * This might not be nesessary...like workers, meta objects represent hight level concept.
 * So we might just list them under meta_objects folder on the same level without any sub-folders.
 * 
 *
 * @author Tim.Liu
 * @created 2013.06.15
 */

var path = require('path');

/**
 * -------------------
 * Private Func Helper
 * -------------------
 * Dive into a fetch a dotPath noted object from host.
 * @param  {[type]} dotPath [description]
 * @param  {[type]} host    [description]
 * @return {[type]}         [description]
 */
function dive(dotPath, host){
	if(!dotPath) return;

	dotPath = dotPath.split('.');
	while(dotPath.length > 0){
		host = host[dotPath.shift()];
	}

	return host;
}

function toCamString(name){
	return name.split(/[^a-zA-Z0-9]/).map(function(sub, i){
				if(i === 0) return sub;
				return sub.charAt(0).toUpperCase() + sub.substr(1);
			}).join('');
}

module.exports = function(app){

	var reg = {
		map: {}
	};

	reg.register = function(location, name){
		//e.g meta-objects, meta.Objects -> metaObjects;
		reg.map[name] = location.split(path.sep).map(function(part){
			return toCamString(part);
		}).join('.');
	};

	/**
	 * Get **Uncompiled** model module def.
	 */
	reg.get = app.getMetaObj = function(name){
		return dive(reg.map[name], app);
	};

	reg.getMap = function(){
		return reg.map;
	}

	/**
	 * Short-cut for exposing method to routes in a meta object.
	 * @param  {[type]}   metaObj [description]
	 * @param  {[type]}   name    [description]
	 * @param  {Function} fn      [description]
	 * @return {[type]}           [description]
	 */
	reg.exposeMethod = app.expose = function(metaObj, name, fn){

		metaObj[name] = fn;
		metaObj.restriction.logic[name] = 'static';

	};	

	return reg;

};