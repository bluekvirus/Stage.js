/**
 * This is the utility that populates the ref and refBy meta blocks for each
 * data model definition. 
 *
 *
 * @author Tim.Liu
 * @created 2013.06.18
 */

module.exports = function(app){

	var util = {};

	util.link = function(def){

		def.Schema.eachPath(function(f){
			try{
				var ref = def.Schema.path(f).options.ref || def.Schema.path(f).caster.options.ref; //one-to-one(enhancement) or one-to-many(ref docs).
				if(ref){
					//meta.ref
					def.meta.ref = def.meta.ref || {};
					def.meta.ref[f] = {model: ref, link: '_' + def.meta.name.toLowerCase() + '_id', oneToOne: def.Schema.path(f).options.ref?true : false};
					if(!def.meta.ref[f].oneToOne) delete def.meta.ref[f].oneToOne;
					
					//meta.refBy (in refed model definition)
					var refed = app.getModelDef(ref);
					refed.meta.refBy = refed.meta.refBy || {};
					refed.meta.refBy[def.meta.name] = {link: def.meta.ref[f].link, parentField:f};
					if(def.meta.ref[f].oneToOne) {
						refed.meta.enhance = refed.meta.enhance || [];
						refed.meta.enhance.push(def.meta.name);
					}

				}
			}catch(e){
				//console.log(def.meta.name + '.' + f + ' is not a ref field');
			}
		});

	};

	return util;
}