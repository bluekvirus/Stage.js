/**
 * This middleware detects server configuration about crossdomain settings. If allowed it will switch it on.
 * It is ONLY for the ajax calls.
 *
 * @author Tim.Liu
 * @created 2013.06.27
 */

module.exports = function(app){

	if(app.config.server.middleware.crossdomain){
		console.log('[Cross-Domain] Enabled');
		return function(req, res, next){
		//enable it
		  res.header("Access-Control-Allow-Origin", req.get('Origin'));
		  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
		  res.header("Access-Control-Allow-Headers", "Content-Type, X-Requested-With");
		  res.header("Access-Control-Allow-Credentials", "true");

		  if(req.method !== 'OPTIONS')
		  	next();
		  else {
		  	res.send(200);
		  }
		};
	}else{
		return function(req, res, next){
			next();
		}
	}

}