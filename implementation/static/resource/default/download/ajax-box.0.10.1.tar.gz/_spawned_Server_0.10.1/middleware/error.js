/**
 * Generic error handling in production server.
 *
 * @author Tim.Liu
 * @created 2013.06.07
 */

function report(statusCode, err, req, res){
	// respond with html page
	if (req.accepts('html')) {
		res.redirect('/'+statusCode+'.html');
		return;
	}

	// respond with json
	if (req.accepts('json')) {
		res.json({ error: err.message }, statusCode);
		return;
	}

	// default to plain-text. send()
	res.type('txt').send(err.message);	
}

module.exports = {

	_404: function(options){
		//options reserved
		
		return function(req, res, next){
			report(404, {message: 'Data Not Found!'}, req, res);
		}
	},

	_500: function(options){
		
		options.handleUncaughtException = options.handleUncaughtException || false;
		if(options.handleUncaughtException){
			process.on("uncaughtException", function(err) {
				console.error("Uncaught exception", "" + err.message);
			});
		}

		return function(err, req, res, next){
		    report(500, err, req, res);
		}
	}

};