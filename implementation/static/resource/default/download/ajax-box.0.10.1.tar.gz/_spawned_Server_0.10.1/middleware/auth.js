/**
 * Authentication & Authorization middleware
 *
 * @author Tim.Liu
 * @create 2013.04.16
 */

var _ = require('underscore');

/**
 * Helper functions
 * @param  {[type]}  failedRedirect [description]
 * @return {Boolean}                [description]
 */
function isAuthenticated(req, res, next){
	if(req.isAuthenticated()){
		next();
	}
	else if(req.app.config.server.middleware.auth.guestPassThrough){
		//login as guest.
		if(req._guestAccount){
			_loginAsGuest(req._guestAccount, req, res, next);
		}else {
			req.app.getModel('User').findByUsername('guest', function(err, guest){
				if(err) throw err;
				req._guestAccount = guest;
				_loginAsGuest(guest, req, res, next);
			});
		}
	}
	else {
		_denyAccess(req, res);
	}
}

function _denyAccess(req, res){
	if(req.xhr || req.is('json'))
		res.json(401, {error: 'Unauthenticated ajax call...'});
	else
		res.redirect('/404.html');
}

function _fixUserFromSession(req){
	//since we don't use the passport.session middleware (conflict with formidable in file-uploads)
	//we provide the req.user retrieval here. the req.session.passport.user is a result of our overridden in the serializeUser() in selective-patch/User.ext.js 
	if(req.session && req.session.passport.user){
		/**
		 * Note:: 
		 * 1. this user is just a username string;
		 * 2. we don't deserialize the user from db using this name string yet;
		 * opt. use req._passport.instance.deserializeUser()...
		 */
		req.user = req.session.passport.user;//we will fix the property in req to be 'user', it is just for the sake of req.isAuthenticated()

	}
}

function _loginAsGuest(guest, req, res, next){
	req.login(guest, function(err){
		if(err) throw err;
		else {
			console.log('Assuming \'guest\' Account...'.blue);
			_fixUserFromSession(req);
			next();
		}
	});
}

//Check if this user is authenticated
module.exports = function(app){

	if(!app.config.server.middleware.auth)
		return function(req, res, next) {
			next();
		}

	var whiteList = app.config.server.middleware.auth.whiteList || {};

	return function(req, res, next){

		if(whiteList[req.method] && whiteList[req.method][req.path]) return next(); //we only expose the key hole to the client.

		_fixUserFromSession(req);
		isAuthenticated(req, res, next);

	}

}

