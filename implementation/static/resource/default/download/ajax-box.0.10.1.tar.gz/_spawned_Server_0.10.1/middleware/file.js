/**
 * This is the file upload middleware, we don't use the express.multipart() for this.
 *
 * ======
 * Design
 * ======
 * Since the 'data' events on req.socket gets lost somehow if there is an I/O operation like fs or db before we can process the form data. We roll our own file upload
 * middleware, so that
 * 1. We can cache the uploaded file in our tmp folder at the same time control the types, sizes and number of files accepted. (req.files has the accepted tmp files)
 * 2. We can validate and varify the tmp files later in the file routes (POST:upload only), and see if the file can be moved to a record's file field folder.
 *
 * @author Tim.Liu
 * @created 2013.10.16
 */

var _ = require('underscore'),
formidable = require('formidable'),
fs = require('fs'),
path = require('path'),
colors = require('colors');

_.str = require('underscore.string');

module.exports = function(app){	

	if(!app.config.server.middleware.fileupload)
		return function(req, res, next) {
			next();
		}

	//obtain and process the fileupload middleware constrains.
	var constrains = app.config.server.middleware.fileupload;
	constrains.maxFileSize = constrains.maxFileSize * 1024 * 1024; //MB to Bytes
	if(constrains.maxNumberOfFiles){
		constrains.maxUploadSize = constrains.maxFileSize * constrains.maxNumberOfFiles;
	}else {
		constrains.maxUploadSize = constrains.maxUploadSize * 1024 * 1024; //MB to Bytes
	}

	//return the middleware.
	return function(req, res, next){
		if(req.method !== 'POST') return next();

		var form = new formidable.IncomingForm({
			uploadDir: app.config.server.support.temp
		});

		form.onPart = function(part){
			if(part.filename){
				//we only handle uploaded files, without form fields.
				form.handlePart(part);
			}
		}

		var tmpFiles = {};
		//listeners
		form.on('fileBegin', function(fieldName, file){
			//type, name and path(tmp)
			//check type and file numbers
			var name = path.basename(file.name);
			var info = _.extend({
				ext: path.extname(file.name),
				accepted: false
			}, _.pick(file, 'path', 'type'));
			switch(constrains.typeFilter){
				case 'allowed':
					if(_.contains(constrains.types, file.type))
						info.accepted = true;
					break;
				case 'banned':
				default:
					if(!_.contains(constrains.types, file.type))
						info.accepted = true;
					break;			
			}
			if(constrains.maxNumberOfFiles > 0 && (_.size(tmpFiles) >= constrains.maxNumberOfFiles))
				info.accepted = false;
			tmpFiles[name] = info;

		}).on('file', function(fieldName, file){
			//size, path(tmp), name, type, hash and lastModifiedDate.
			//check size of file
			var name = path.basename(file.name);
			if(file.size > constrains.maxFileSize)
				tmpFiles[name].accepted = false; //mark for removal.
			else {
				_.extend(tmpFiles[name], _.pick(file, 'size', 'hash', 'lastModifiedDate'));
			}

		}).on('progress', function(bytesReceived, bytesExpected){
			//check upload limitations on total size
			if(bytesExpected > constrains.maxUploadSize){
				//sever the connection.
				throw new Error('Exceeds Max Upload Size...');
			}

		}).on('error', function(err) {
			//mark to be cleaned up, see filters - cleanUpUnwantedFiles. 
			req.fileError = err.message;
			req.files = tmpFiles;
			next();

		}).on('aborted', function(){
			//mark to be cleaned up
			req.fileError = 'File Upload aborted by user';
			req.files = tmpFiles;
			next();

		}).on('end', function(){
			if(!req.fileError){
				req.files = tmpFiles;
				next();
			}
		}).parse(req);
	}

}