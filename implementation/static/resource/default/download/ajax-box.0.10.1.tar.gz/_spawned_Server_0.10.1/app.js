/**
 * **The Server node** 
 *
 * Master Rule:: See how data FLOWS! Focus!!
 *
 * --------------
 * Client Web Req
 * --------------
 * ||||||||||||||
 * Middlewares
 * ||||||||||||||
 * --------------
 * Routes
 * --------------
 * Models
 * --------------
 * DB & [Background Jobs]
 * --------------
 * Log & Statistics
 * --------------
 * 
 * This is the re-factored server node to be used as a GENERAL (promote Model + Middleware) backend.
 * It is to server 3 different kinds of resources of any given ENTITY (model or meta object):
 * 	
 * 	1. data;
 * 	2. file;
 * 	3. logic;
 *
 * Being general suggests that it will leave the View out of the conventional
 * MVC architecture to be within the client javascript code. Only to focus on serving
 * data & files with generic middleware guards and routes in the json data format.
 * 
 * As for the logic part, it will mainly be used as a complimentary group of functions 
 * to serve the need of routines other than basic data/file operations. It is also a hook to 
 * the background worker process. Logic methods appear as 'static/instance methods' in a given entity
 * model definition. If a fake model without data/file but only logic routines is needed, use a
 * meta object instead.
 *
 * Now, given that conventional MVC server applications always have 'filters' in the concept 
 * to help with pre/post routes/operations/actions hooks, we keep generic 'filters' in one place and
 * only applies to routes. see /routes/filters.js
 *
 * So, with the above design in mind, the architecture (from the project structure POV) becomes as simple as this:
 *
 * Parts:
 * 	/config - various configurations for different parts of the server.
 * 	/util - utility obj/functions.
 * 	/models and /meta-objects (logic only) - fields(+validations), methods(+hooks), relations
 * 	/workers - background job workers.
 * 	/middleware - generic processing of client req (auth & auth, data/logic api, file upload/download)
 * 	/stack - middleware setups.
 * 	/routes - specific data/operation routes other than those in the middleware, more bound towards non-model related general actions.
 *
 * Support:
 * 	/temp - temp file folder
 * 	/upload - upload file dir
 * 	/tools - the development supporting tools, (e.g code generators)
 *
 * Loading Seq (using express-load: https://github.com/jarradseers/express-load)
 * 	/config -> /util -> /models -> /workers -> /middleware -> /stack -> /routes -> (/tools)
 * 	=========================================
 * 	After loading parts
 * 	=========================================
 * 	app.use(...) - middleware -- see config under /stack 
 *
 * Then app.config.x, app.models.x and app.workers.x are available throught out the application server.
 * Within middleware, use req.app.config.x, req.app.models.x and req.app.workers.x instead.
 * 
 */

var express = require('express')
  , http = require('http')
  , path = require('path') //for path building compatibility on different OS
  , fs = require('fs')
  , load = require('express-load')
  , colors = require('colors')
  , serverInfo = require('./package.json');


/**
 * ==========
 * Init...
 * ==========
 */
//create app var and adjust some settings - note that the view folder is just for login page.
var app = express();
load('appsettings.js').into(app);


/**
 * ==========
 * Loading...
 * ==========
 */
//load config and utilities before other parts
load('config').then('util').into(app);
app.config = app.config[app.get('env')];


//load other parts (use path.join to be compatible on different OS host)
//model loading exception reports to app.util.resolver
load('models').then('meta_objects').then('workers').into(app);
app.util.modelloadresolver.resolve();


//load server middleware stack
load('middleware').then('stack').into(app);
app.stack[app.get('env')].setup(app);


//load routines after server stack for them to work e.g static and req.body.
load('routes/filters.js').then('routes').into(app);


//load dev tools into app (e.g resource/meta model generator).
if(app.config.tools)
	load('tools').into(app);


/**
 * ==========
 * Running...
 * ==========
 */
//0 create the support folders (the upload folder will be created automatically when there is upload)
if(!fs.existsSync(app.config.server.support.temp))
	fs.mkdirSync(app.config.server.support.temp)

//init (db) & start (web server, backend processes...)
//1 mongo db
app.set('db_mongo', app.util.dbconnection.connect('mongodb'));
//2 web server
app.get('db_mongo').once('open', function(){
	//a. wake up all models - use their schemas.
	app.util.modelmap.wakeup(app.get('db_mongo'));
	//b. config passport - need the User model.
	app.util.configpassport.setup();

	//open for business
	http.createServer(app).listen(app.config.server.port, function(){
		console.log("[Express] server listening on port " + app.config.server.port.yellow);
		console.log('['.grey, serverInfo.name.magenta, '-', serverInfo.version.grey, 'by', serverInfo.author.blue, ']'.grey);
		console.log('[Server Stack:'.yellow, app.get('env').cyan, ']'.yellow);
		console.log('[Web Client:'.yellow, path.resolve(app.config.server.clientPath).cyan , ']'.yellow);
	});  

})


 