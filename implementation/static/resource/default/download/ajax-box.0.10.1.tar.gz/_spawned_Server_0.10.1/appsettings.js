/**
 * Express App Settings. (Regrouped)
 *
 * @author Tim.Liu
 * @created 2013.06.16
 */

//dealing with different env 
var args = process.argv.slice(2);

module.exports = function(app){

	app.set('env', args[0] || 'production');
	// app.set('views', __dirname + '/views');
	// app.set('view engine', 'jade');

};