/**
 * This is the general data api router.
 * Each Entity will have two possible route format
 *
 * Standard: (Self)
 * ---------
 *  GET: (collection)
 *  POST:
 *  	/data/:[Entity name]/ 
 * 	GET: (record)
 * 	PUT:
 * 	DELETE:
 * 		/data/:[Entity name]/:[id attribute value]
 *
 * Nested: (Ref-ed model)
 * ---------------------------
 * 	GET: (collection)
 * 	POST:
 * 		/data/:[Entity name]/:[id attribute value]/:[field name]/
 * 	GET: (record)
 * 	PUT:
 * 	DELETE:
 *  	/data/:[Entity name]/:[id attribute value]/:[field name]/:[id attribute value]
 *
 *
 * When a *Parent* Entity gets deleted, two clean up options are available:
 * 1. immediately go to scan the schema and delete related models.
 * 2. stops there, let the related models/files run a scheduled maintenance call later.
 *
 * Sorting and Pagination
 * Params: sort_by, order[asc/desc], page, per_page -- see /routes/filter.js
 *
 * Route Matching Suggestion
 * Not strictly and non-case-sensitive
 *
 * 
 * ---------------------------
 * **Warning**
 * Sub-Docs won't ensure index
 * Ref-Docs do ensure index
 * ---------------------------
 *
 * 
 * @author Tim.Liu
 * @created 2013.05.31
 *
 * 
 */
var _ = require('underscore'),
colors = require('colors');

module.exports = function(app){

	var urlbase = app.config.server.apiBase.data;
	// [pre/post] filters from /routes/filters.js
	var pre = app.routes.filters.pre.api.data,
		post = app.routes.filters.post.api.data;

	/**
	 * (Self) Collection
	 */
	
	//1. GET - list - pagination checks in pre.prep.checks
	//-------------
	app.serve('general.data.std.read', 'get', urlbase + '/:model', pre.guards.byModel, pre.prep.list, function(req, res, next){

		
		var criteria = {}; //apply criteria [e.g like in where(...)], for server side searching support.

		//apply mutex rules - see filters mutex;
		_.extend(criteria, req.mutexRules);

		//1 Get the total count - we issue 2 queries instead of using in-memory solutions for server clustering.
		req.target.find(criteria).count(function(err, count){
			if(err) res.json(500, {error: err.message});
			else {
				//2 Get the records
				req.target.find(criteria)
				.sort(req.sortArg)
				.skip(req.offset)
				.limit(req.query.per_page)
				.exec()
				.then(function(docs){
					res.json({payload:docs, total:count});
				})
				.then(null, function(err){
					res.json(500, {error: err.message});
				})
				.end();				
			}
		});

	}, post.error);
	
	//2. POST - create (don't need to apply mutex rule)
	//----------------
	app.serve('general.data.std.modify', 'post', urlbase + '/:model', pre.guards.byModel, pre.prep.ownerAndSpace, function(req, res, next){

		req.target.create(req.body, function(err, doc){
			if(err) res.json(500, {error: err.message});
			else res.json({payload:doc});
		});

	}, post.error);

	/**
	 * (Self) Record
	 */
	
	//1. GET - read
	//--------------
	app.serve('general.data.std.read', 'get', urlbase + '/:model/:key', pre.guards.byRecord, function(req, res, next){

		res.json({payload:req.doc});

	}, post.error);

	//2. PUT - update
	//---------------------
	app.serve('general.data.std.modify', 'put', urlbase + '/:model/:key', pre.guards.byRecord, function(req, res, next){

		//we need model middlewares to apply so we don't use update() here but to set() and trigger pre('save')

		//apply mutex if it is in the User space
		if(req.readOnlyByUser) throw new Error('401:You can NOT modify this record...');

		req.doc.set(req.body);
		req.doc.save(function(err, saved){
			if(err) res.json(500, {error: err.message});
			else res.json({payload: saved});
		});


	}, post.error);

	//3. DELETE - remove
	//**WARNING**: no middleware applied due to mongoose implementation
	//[see: http://mongoosejs.com/docs/api.html#model_Model.remove]
	//-------------------
	app.serve('general.data.std.modify', 'delete', urlbase + '/:model/:key', pre.guards.byRecord, function(req, res, next){

		//apply mutex if it is in the User space
		if(req.readOnlyByUser) throw new Error('401:You can NOT modify this record...');

		req.target.remove({_id: req.doc.id}).exec()
			.then(function(affected){
				res.affected = affected;
				next();
			})
			.then(null, function(err){
				res.json(500, {error: err.message});
			})				
			.end();

	}, function(req, res, next){

		//TBI clean ups: files
		next();
		
	}, post.cleanup, //hooks up with data model's own post_remove extension static method.
	function(req, res, next){

		if(res.affected === 1){
			res.json({affected: res.affected});

			//[OPTIONAL] delete everything it ref-ed.[this might not be a good idea...since the same record might be ref-ed by others as well]
			// _.each(req.targetDef.meta.ref, function(ref, refField){
			// 	app.getModel(ref.model).where('_id').in(req.doc[refField]).remove(function(err, noa){
			// 		if(!err) console.log('[Cleanups]-[', req.params.model, ']-[', refField, ']:', noa);
			// 		else console.log(err.message);
			// 	});
			// });

			//[MUST] delete the ref-key that resides in every parent record that ref-ed this one.
			_.each(req.targetDef.meta.refBy, function(refBy, pModelName){
				var pModelDef = app.getModelDef(pModelName);
				pModelDef.Model.where('_id', req.doc[refBy.link]).findOne(function(err, pDoc){
					if(!err && pDoc){
						//remove the key from ref collection field of parent doc
						pDoc[refBy.parentField].remove(req.doc._id);
						pDoc.save(function(err){
							if(err) console.log(String(err.message).red);
							else console.log(pModelName, pDoc._id, refBy.parentField, 'updated...');
						});
					}
				});
			});
			
		}else {
			throw new Error('401:Can NOT delete this record!');
		}
		
	}, post.error);


	/**
	 * (Ref-ed model) Collection
	 */
	//1. GET - list - note that this also serves the one-to-one enhancement model instance content of a parent record.
	//---------------------------
	app.serve('general.data.ref.read', 'get', urlbase + '/:model/:key/:field', pre.guards.byRecordField, pre.prep.list, function(req, res, next){

		if(req.requestedFieldServeType === 'normal'){
			var result = req.doc[req.params.field];
			if(result) res.json({payload: result});
			else throw new Error('Requested field does not belong to the given record...');
		}

		else {
		//'ref' - note that we can NOT use _.isEmpty() check here, it'd return false even if there is nothing in the ref field.
			//1. check if it is a empty one-to-one ref field.
			//skipped. no good way of impl here atm.

			//2. apply re-checked mutex rules.
			var criteria = _.extend({}, req.mutexRules); //like in where(...), can also contain server search querys later, TBI

			//3. populate the ref field.
			req.doc.populate({
				path: req.params.field,
				match: criteria,
				options: {
					skip: req.offset,
					limit: req.query.per_page,
					sort: req.sortArg,
				}
			}, function(err, doc){
				if(err) res.json(500, {error: err.message});
				else res.json({payload:doc[req.params.field]}); //we currently do not reply with ref collection 'count'.
				//the client side should use paginator in 'infinite' mode for holding this ref collection.
			});
		}

	}, post.error);

	//2. POST - create (don't need to apply mutex rule) Collection only
	//----------------------------------**Warning**-------------------------------------------------
	//As in mongodb we use _id as the ref key no matter what keyField the refed doc model prefers...
	//----------------------------------------------------------------------------------------------
	app.serve('general.data.ref.modify', 'post', urlbase + '/:model/:key/:field', pre.guards.byRecordField, pre.prep.ownerAndSpace, function(req, res, next){

		if(req.requestedFieldServeType !== 'ref'){
			throw new Error('Requested field is not a referenced collection...');
		}

		if(!_.isArray(req.doc[req.params.field])){
			throw new Error('Requested field does NOT support post to create...');
		}		

		req.subTarget.create(req.body, function(err, sub){
			if(err) return res.json(500, {error: err.message});
			if(sub){
				//save the ref doc _id in parent doc
				if(_.isArray(req.doc[req.params.field]))
					req.doc[req.params.field].push(sub);
				else
					req.doc[req.params.field] = sub._id;
				req.doc.save(function(err){
					if(err) {
						req.subTarget.remove({_id: sub._id}).exec()
									.then(null, function(err){
										console.log('[ERROR - Cleanup]', err);
									});						
						res.json(500, {error: err.message});
					}
					else {
						var pid = {};
						pid[req.subTargetDef.meta.refBy[req.params.model].link] = req.doc._id;
						sub.update(pid, function(err, noa){ //noa - number of affected
							if(!err && noa === 1){
								res.json({payload: sub});
							}else{
								if(err) res.json(500, {error: err.message});
								else res.json(500, {error: 'You can NOT add sub records to this field.'});
							}
						});
						
					}
				});				
			}
		});

	}, post.error);

	/**
	 * (Ref-ed model) Record
	 * ckey - child record key
	 */
	//1. GET - read
	//--------------------------
	app.serve('general.data.ref.read', 'get', urlbase + '/:model/:key/:field/:ckey', pre.guards.byRecordField, pre.prep.refDoc, function(req, res, next){

		res.json({payload:req.refDoc});

	}, post.error);

	//2. PUT - update
	//--------------------------
	app.serve('general.data.ref.modify', 'put', urlbase + '/:model/:key/:field/:ckey', pre.guards.byRecordField, pre.prep.refDoc, function(req, res, next){

		//apply mutex rule
		if(req.refDocReadOnlyByUser) throw new Error('401:You can NOT modify this ref record...');

		req.refDoc.set(req.body);
		req.refDoc.save(function(err, saved){
			if(err) res.json(500, {error: err.message});
			else res.json({payload: saved});
		});

	}, post.error);

	//3. DELETE - remove
	//--------------------------**Warning**-----------------------------------
	// We go on clean up the ref-ed doc, but it should stay if it is also
	// needed by other models... So a later clean up check should be triggered
	// instead making it a more thoughtful process...
	//------------------------------------------------------------------------
	app.serve('general.data.ref.modify', 'delete', urlbase + '/:model/:key/:field/:ckey', pre.guards.byRecordField, pre.prep.refDoc, function(req, res, next){

		//apply mutex rule
		if(req.refDocReadOnlyByUser) throw new Error('401:You can NOT modify this ref record...');		

		req.doc[req.params.field].remove(req.refDoc._id);
		req.doc.save(function(err){
			if(err) res.json(500, {error: err.message});
			//[Optional - clean up the ref-ed record as well...]
			else req.subTarget.remove(req.refCondition).exec()
					.then(function(affected){
						res.json({affected:affected});
						next();
					})
					.then(null, function(err){
						res.json(500, {error: err.message});
					})				
					.end();

		});


	}, function(req, res, next){

		//TBI clean ups: files
		next();
		
	}, function(req, res, next){
		
		//TBI clean ups: related models

	}, post.error);

};