/**
 * Shared Routers as Filters
 * The request filter functions for guarding data/file/logic APIs in routes
 *
 * e.g. authorization, same role mutex...
 * 
 * @author Tim.Liu
 * @created 2013.06.05
 */

var _ = require('underscore'),
path = require('path'),
fs = require('fs');

module.exports = function(app){
	/**
	 * Authorize users with correct route group name tag in their privilege_map. see - User.ext.js, Resources.js & util/namedroutes.js
	 */
	function authorize(req, res, next){
		//let admin or auth-disabled pass: 
		if(!req.user || (req.user.name === 'superadmin'))
			return next();

		if(req.user.privilegeMap){
			//normal user with assgined privileges:
			var object = req.params.model;
			/*WARNING::these vars are subjected to change, whenever the :var used in the routes changes*/
			var key = req.params.field || req.params.filefield || req.params.methodName || undefined;
			var pItem = req.user.privilegeMap[object]; //model lvl
			pItem = pItem && pItem[req.routeGroup]; //tag lvl (route group name tag)

			if(pItem){
				if(pItem === true || pItem.hasOwnProperty(key))
					return next();
			}
		}

		//new user or unauthorized user
		throw new Error('401:Unauthorized data access...');

	};

	/**
	 * Mutex filter. see - auto-patch/mutex.js
	 * + mutex rule related.
	 */
	function mutex(req, res, next){
		//let auth-disabled pass:
		if(!req.user) return next();

		var user = req.user;
		req.mutexRules = {};
		
		//1. apply user's account_space >= record's _space restriction
		_.extend(req.mutexRules, {
			$or: [{_space :{$lte: app.config.spaceScale[req.user.space]}}, {_space: {$exists: false}}]
		});

		//2. apply User space's mutex settings configured by Model def meta.
		if(req.app.config.spaceScale[user.space] === req.app.config.spaceScale['User']) {
			//we consult the mutex settings from the model and compare the user's account_space with the record's _space as well.
			req.inUserSpace = true;
			//apply 'User' space mutex
			if(req.targetDef.meta.mutex === 'private') req.mutexRules._owner = req.user.name;
		}

		next();
	};

	/**
	 * For adding req.user as _owner during record creation (upon POST)
	 * also we tag the record with the creator's account_space.
	 * + mutex rule related.
	 */
	function injectOwnerAndSpace(req, res, next){
		var user = req.user;
		if(user){
			req.body._owner = user.name; //inject user as the _owner of the data.
			if(req.targetDef.meta.imposeOwnerSpace)
				req.body._space = req.app.config.spaceScale[user.space] || req.app.config.spaceScale['User']; //inject user account space as the space of the data.
			else
				req.body._space = req.app.config.spaceScale['User']; //use lvl 0 as the record's space.
			//This way, when a super-admin creates a record, it will still be his when he choose to down grade it to 'User' space.
			//Also, he can choose to give it to someone else completely or as a co-author by changing the record's _owner or _collaborators array.
			//Users can only see/modify records that are equal or below his account_space lvl. 
		}
		next();	
	}

	//=======Data=========
	//
	/**
	 * for /[api]/:model/...
	 * :model -> req.targetDef(Definition), req.target(Compiled Model)
	 */
	function grabModel(req, res, next){

		var def = req.app.getModelDef(req.params.model);
		if(def){
			req.targetDef = def;
			req.target = def.Model;
			next();
		}else
			throw new Error('Resource Not Found...');

	};

	/**
	 * for /[api]/:model/:key(/:field/:ckey)?
	 * {keyField:key} -> req.condition
	 * 
	 * **NOTE** 
	 * If ref-doc :ckey presents we also add {reffield:ckey} to the condition obj.
	 * This is making sure in refDoc filter, what we get is related to the parent doc.
	 */
	var validKey = /^[_a-zA-Z0-9]+$/; //_, alpha, number mix allowed. 
	function grabKey(req, res, next){

		//[Avoid File Upload Hang] -> Should check key's pattern for security...only _/[a-zA-Z]/numbers can be used...
		if(!validKey.test(req.params.key)){
			throw new Error('Invalid Record Identifier...');
			return;
		}

		req.condition = req.condition || {};
		req.condition[req.targetDef.meta.keyField] = req.params.key;
		//make sure if we are looking for the ref-ed doc, it is ACTUALLY ref-ed by the parent doc.
		if(req.params.field && req.params.ckey)
			req.condition[req.params.field] = req.params.ckey;
		next();

	};

	/**
	 * for /[api]/:model/:key
	 * find() -> doc -> req.doc
	 * + mutex rule related.
	 */
	function findOne(req, res, next){

		req.target.findOne(_.extend(req.condition, req.mutexRules), function(err, doc){

			if(err) return res.json(500, {error: err.message});
			if(doc){
				req.doc = doc;

				//apply additional mutex rule check support;
				//do a further check to flag out if this doc can be modified by user if he/she is in the User space
				if(req.inUserSpace && req.targetDef.meta.mutex !== 'disabled'){
					//check if the req.user.name is in _owner or _collaborators, if not, we flag Read-Only to true;
					if((req.doc._owner !== req.user.name) && !_.contains(req.doc._collaborators, req.user.name)){
						req.readOnlyByUser = true;
					}
				}

				return next();
			}
			//in case it is used after the file upload filter(it was actually a middleware, delayed)
			if(req.files){
				req.fileError = 'File Host Record Not Found...';
				next();
			} 
			else
				res.json(500, {error: 'Record Not Found...'});

		});

	};

	/**
	 * for /[api]/:model/:key/:field (ref-field or normal field of a record)
	 */
	function fieldNormalOrReffed(req, res, next){

		//check with the already prepared meta-data in model definition. see util/modelrealtionship.js
		if(!req.targetDef.meta.ref || !req.targetDef.meta.ref[req.params.field])
			req.requestedFieldServeType = 'normal';
		else {
			req.requestedFieldServeType = 'ref';
		}
		next();

	}

	function reCheckMutexOnSubModel(req, res, next){
		//if the user is the modifier of parent record (!req.readOnlyByUser), then he/she should have full api access without User space mutex setting check on the sub table Model meta.
		//if not, only if the sub table Model has further constrains should we re-emphasize the 'private' mutex constrain.
		if(req.requestedFieldServeType !== 'ref') return next();
		
		var def = req.app.getModelDef(req.targetDef.meta.ref[req.params.field].model);	
		req.subTarget = def.Model;
		req.subTargetDef = def;

		if(req.readOnlyByUser && req.subTargetDef.meta.mutex === 'private'){
			req.mutexRules._owner = req.user.name; //in case if parent model's mutex is read-only. the sub model docs can still be private.
		}
		next();
	}

	/**
	 * for /[api]/:model/:key/:field(/:ckey)?
	 * :field -> req.subTargetDef (model definition)
	 * 		  -> req.subTarget (model)
	 *
	 * + mutex rule related.
	 */
	function refDoc(req, res, next){

		if(req.requestedFieldServeType !== 'ref'){
			throw new Error('Requested field is not a referenced collection...');
		}

		if(req.params.ckey){
			
			req.refCondition = {};
			req.refCondition[req.subTargetDef.meta.keyField] = req.params.ckey;
			req.subTarget.findOne(_.extend(req.refCondition, req.mutexRules)).exec()
				.then(function(ref){
					if(ref){
						req.refDoc = ref;

						//if req.readOnlyByUser is not true, and that means the user is a qualified modifier of the parent doc, it will have full power over the ref-ed docs.
						if(req.inUserSpace && req.subTargetDef.meta.mutex !== 'disabled' && req.readOnlyByUser){
							if((req.refDoc._owner !== req.user.name) && !_.contains(req.refDoc._collaborators, req.user.name)){
								req.refDocReadOnlyByUser = true;
							}
						}

						return next();
					}

					//this should not be reached...since both parent and ref doc _id was in the search condition.
					//it should have been detected by the findOne filter...
					throw new Error('Ref Record Not Found...'); 
				})
				.then(null, function(err){
					res.json(500, {error: err.message});
				}).end();			
		}else
			next();
	}

	/**
	 * for detecting pagination switch
	 * ?pagination=false? -> req.query.per_page = 0
	 * 			  
	 */
	function checkPagination(req, res, next){
		req.query.per_page = (req.query.pagination === 'false'? 0: req.query.per_page);
		req.offset = (req.query.page-1)*req.query.per_page;
		next();
	}

	/**
	 * for detecting sort args
	 * ?sort_by, order[asc/desc]
	 * Sorting out the request's sort args for Query.sort()
	 */
	function _order(order){
		switch(order){
			case 'asc': case '1':
				return 1;
			case 'desc': case '-1':
				return -1;
			default:
				return 1;
		}
	}
	function checkSortArgs(req, res, next){

		var sortArg = {};		
		var sortBy = req.query.sort_by;
		var order = req.query.order;

		//A.simple version, only one sort_by and one order query.
		if(sortBy){
			sortArg[sortBy] = _order(order);	
		}else
			sortArg = undefined;

		req.sortArg = sortArg;
		next();
	}

	/**
	 * Invoke the data model's post_remove hook if available in its extension.
	 * [WARNING:: this is because mongoosejs won't provide post/pre hooks for remove/update methods]
	 */
	function afterRemovalExtensionHook(req, res, next){
		if(req.target.post_remove) req.target.post_remove(req.doc);
		next();
	}

	/**
	 * Reply with the error/exception thrown.
	 * '401:error...' - sends 401, error...
	 * 'error...' - sends 500, error...
	 * ''
	 */
	function replyError(err, req, res, next){
		var code = err.message.split(':');
		code = code.length > 1? Number(code[0]): 500;
		res.json(code, {error:err.message});
	}

	//=======Files========

	/**
	 * 1. check if this field is a file field;
	 * 2. check if a upload dir is available
	 */
	function checkUploadDir(req, res, next){
		var check = req.targetDef.restriction.file[req.params.filefield];
		if(!check || !(check && check.enabled))
			throw new Error('File field invalid...'); //this field is not a valid/enabled file field.
		
		req.uploadDir = path.join(app.config.server.support.upload, req.params.model, req.params.key, req.params.filefield);
		fs.exists(req.uploadDir, function(exists){
			req.uploadDirExists = exists;
			next();
		});		
		
	}

	//applies to file upload only.
	//since the config of file upload middleware only constrains files in a single upload.
	//we only need to mark the unwanted files. later filer will remove them altogether.
	//mutex applied
	function checkFileRestriction(req, res, next){
		if(req.fileError) return next();
		if(req.readOnlyByUser) {
			req.fileError = 'You are not allowed to upload files to this one';
			return next();
		}
		//TBI - delete and remove unwanted files from req.files according to Model meta file restrictions.
		//1. total folder size;
		//2. total file numbers;
		//3. single file size (min, max); in addition to the one set by file upload middleware
		//4. types allowed;
		next();
	}


	function cleanUpUnwantedFiles(req, res, next){
		if(req.fileError){
			_.each(req.files, function(info){
				info.accepted = false;
			});
		}

		_.each(req.files, function(info, name){
			if(info.accepted) return;

			delete req.files[name];
			fs.unlink(info.path);
		});

		if(_.size(req.files) > 0){
			next();
		}else {
			var msg = req.fileError || 'Upload rejected...check your file size(<' + app.config.server.middleware.fileupload.maxFileSize/(1024*1024) + ' MB) and type...';
			res.json(500, {error: msg});
		}
		
	}

	//=======Logic========

	function grabMetaObjOrModel(req, res, next){
		
		var mo = req.app.getMetaObj(req.params.model);
		if(mo){
			req.targetDef = req.target = mo;
			next();
		}else grabModel(req, res, next);

	}

	function logicExposed(req, res, next){

		if(req.targetDef.restriction.logic[req.params.methodName]) next();
		else throw new Error('Method Un-defined/exposed...');

	}

/**
 * =========================
 * Regroup and Expose
 * =========================
 */
	return {
		//---------------------
		pre: {

			api: {
				data: {
					guards: {
						byModel: [ authorize, grabModel, mutex ],
						byRecord: [ authorize, grabModel, mutex, grabKey, findOne ],
						byRecordField: [ authorize, grabModel, mutex, grabKey, findOne, fieldNormalOrReffed, reCheckMutexOnSubModel], //note that the reCheckMutexOnSubModel will also set req.subTargetDef.
					},
					prep: {
						list: [ checkPagination, checkSortArgs ],
						refDoc: refDoc,
						ownerAndSpace: injectOwnerAndSpace,
					},
				},

				file: {
					//**WARNING** we need to use findOne after file upload...coz I/O before formidable will cause the 'data' events to get lost...
					guards: {
						up: [ authorize, grabModel, mutex, grabKey, app.middleware.file, findOne, checkUploadDir, checkFileRestriction, cleanUpUnwantedFiles],
						down: [ authorize, grabModel, mutex, grabKey, findOne, checkUploadDir ]
					}

				},

				logic: {
					guards: { //we don't put mutex filter here since it is not standard data operations; 
							  //req.user is passed to the methods as options.user, for space specific behaviours;
						statics: [ authorize, grabMetaObjOrModel, logicExposed ],
						instance: [ authorize, grabModel, logicExposed , grabKey, findOne ]
					}
				}
			}

		},

		//---------------------
		post: {
			api: {
				data: {
					error: replyError,
					cleanup: [ afterRemovalExtensionHook ],
					transform: {} //not in use yet...requires delaying data routes result return;
				},
				file: {
					error: replyError,
				}
			}
		}

	}


};