/**
 * Moving the /middleware/fileupload.js's job here...
 *
 * We only serve 1-lvl of file attachment, thus we do NOT support file
 * attachment for sub-docs only for normal and ref-docs.
 *
 * Restrictions:
 * 
 * basic
 * 1. file type -> types white list
 * 2. file size -> single file size limit
 * 
 * optional
 * 3. maximum number of files -> 0: unlimited
 * 							  -> 1+: limited by this number, replacing same name, replacing FIFO
 * 4. maximum disk space -> 0: unlimited
 * 							1+: total disk space allowed for this entity(per record).
 *
 *
 * Routes: [depends on model type]
 * upload -> GET/POST/DELETE /uploads/:model/:key/:filefield(/:filename)?
 * download -> GET /file/:model/:key/:filefield/:filename
 * 
 * :key can be 'shared' so that all the records of an entity can share the uploaded files.
 *
 * Guards: [the mutex guards applies as well, see routes/filters.js - mutex]
 * 1. :model exists
 * 2. :model.:key exists unless it says shared
 * 3. :model.:key.:filefield is indeed a file field (registered in model def restriction)
 * Note that the mutex settings of a Model also applies to the file uploading.
 *
 * Since files are not stored in the database, there will be no file records info in a data record. 
 * Still we treat the file records under a field(which doesn't really exists) to be like normal field, only, we fetch the files info through the file apis instead of data ones.
 *
 * 
 * @author Tim.Liu
 * @created 2013.06.07
 */

//var upload = require('jquery-file-upload-middleware'),
var path = require('path'),
fs = require('fs'),
mkdirp = require('mkdirp'),
_ = require('underscore');

module.exports = function(app){

	var urlbase = app.config.server.apiBase.file;
	// [pre/post] filters from /routes/filters.js
	var pre = app.routes.filters.pre.api.file;
	var post = app.routes.filters.post.api.file;
	

	//---------------------------Listing------------------------
	//GET all files info for this record
	//----------------------------------------------------------
	app.serve('general.file.std.read', 'get', urlbase.upload + '/:model/:key/:filefield', pre.guards.down, function(req, res, next){

		if(!req.uploadDirExists) return res.json({files: []});

		fs.readdir(req.uploadDir, function(err, files){
			if(err) return res.json(500, {error: err.message});
			//obtain file stats
			if(files.length > 0){
				var stats = [];
				_.each(files, function(fname){
					fs.stat(path.join(req.uploadDir, fname), function(err, stat){
						if(err) return console.log('Error'.red, err.message);
						stats.push({
							name: fname,
							size: stat.size,
							time: stat.mtime,
							url: [urlbase.upload, req.params.model, req.params.key, req.params.filefield, fname].join('/')
						});
						if(stats.length === files.length)
							res.json({files: stats});
					});
				});
			}else {
				res.json({files:[]});
			}
		});

	}, post.error);


	//----------------------Upload------------------------
	//POST a file to the record file folder
	//----------------------------------------------------
	app.serve('general.file.std.modify', 'post', urlbase.upload + '/:model/:key/:filefield', pre.guards.up, function(req, res, next){

		if(!req.uploadDirExists) mkdirp.sync(req.uploadDir);
		_.each(req.files, function(info, name){
			//move files to record's file field folder.
			fs.rename(info.path, path.join(req.uploadDir, name), function(err){
				if(err) return console.log('Error'.red, err.message);
			});
		});
		res.json({msg: 'File uploaded...',  files: _.keys(req.files)});

	}, post.error);	
	
	//--------------------Reading-------------------------
	//GET file serving as content.
	//----------------------------------------------------
	app.serve('general.file.std.read', 'get', urlbase.upload + '/:model/:key/:filefield/:filename', pre.guards.down, function(req, res, next){
		if(!req.uploadDirExists) throw new Error('File not found...');
		res.sendfile(path.join(req.uploadDir, req.params.filename));
	}, post.error);
	
	//--------------------Attach------------------------------
	//GET file as attachment, trigger client's download dialog
	//--------------------------------------------------------
	app.serve('general.file.std.read', 'get', urlbase.download + '/:model/:key/:filefield/:filename', pre.guards.down, function(req, res, next){
		if(!req.uploadDirExists) throw new Error('File not found...');
		res.download(path.join(req.uploadDir, req.params.filename));
	}, post.error);


	//--------------------Delete------------------------
	//DELETE a file
	//--------------------------------------------------
	app.serve('general.file.std.modify', 'delete', urlbase.upload + '/:model/:key/:filefield/:filename', pre.guards.down, function(req, res, next){
		var target = path.join(req.uploadDir, req.params.filename);
		fs.unlink(target, function(err){
			if(err) return console.log('Error'.red, err.message);
			res.json({msg:'File deleted successfully!', path:target});
		});
	}, post.error);
};