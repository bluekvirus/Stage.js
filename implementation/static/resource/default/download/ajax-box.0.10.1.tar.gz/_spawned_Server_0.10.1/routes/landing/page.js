
/*
 * GET dull landing pages (login, index, contact...);
 *
 * @author Tim.Liu
 * @updated 2013.06.02
 */
var path = require('path');

module.exports = function(app){
	/**
	 * -----------
	 * Definitions
	 * -----------
	 */
	var page = {

		logout : function(req, res){
			req.logout();
			//res.redirect('/');
			res.json({msg:'User logged out...'});
		},

		forbidden : function(req, res){
			res.redirect('/404.html');
		}

	};


	/**
	 * ---------------
	 * Wiring up
	 * ---------------
	 */

	app.get('/login', function(req, res){
		//login check by ajax calls, we do not serve the static login page anymore from server.
		res.json({authenticated: true, msg:'Please proceed with other ajax calls...', user: req.user});
	});
	app.post('/login', function(req, res, next){
		req.body.password = req.body.password || '.';
		next();
	}, app.util.configpassport.getInstance().authenticate('local'), function(req, res){
		req.user = req.session.passport.user;
		res.json(req.user);  
	});
	app.get('/logout', page.logout);

}

