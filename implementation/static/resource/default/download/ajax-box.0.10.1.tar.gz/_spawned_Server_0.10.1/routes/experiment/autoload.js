/**
 * Auto-load client side scripts
 *
 * We will also load .module.js before .extension.js
 *
 * @author Tim.Liu
 * @updated 2013.06.02
 */

var fs = require('fs'),
	_  = require('underscore');

module.exports = function(app){

	app.get('/tryscripts', function(req, res){

		var fileListing = {};
		var js = new RegExp('\\.js$');
		var modulejs = new RegExp('\\.module.js$');
		var extensionjs = new RegExp('\\.extension.js$');
		fs.readdir(app.config.server.clientPath + '/' + req.query.payload, function(err, files){
			if(!err){
				fileListing['files'] = _.filter(files, function(f){
					return js.test(f);
				});
				fileListing['modules'] = _.filter(files, function(f){
					return modulejs.test(f);
				});
				fileListing['extensions'] = _.filter(files, function(f){
					return extensionjs.test(f);
				});
				fileListing['others'] = _.difference(fileListing['files'], fileListing['modules'], fileListing['extensions']);
			}
			else{
				fileListing['error'] = err;
			}
				
			//Loading priority sorted on the client side, we only categorize things on server.
			
			//TBI
			//[Optionally order on server and zip to client in 1 file.]
			
			res.json(fileListing);
		})
	});


	
};