/**
 * This is the general route for exposed routines from models.
 *
 * Access Control needs to be reported to 'Resource' model as metadata.
 * Else, all the methods and statics from a given model will be exposed
 *
 * Route Pattern:
 * GET/POST/PUT/DEL /logic/:model/:method name -> model static methods
 * GET/POST/PUT/DEL /logic/:model/:key/:method name -> model instance methods
 *
 * Guards: [the mutex guard also applies...]
 * :model exists
 * :model:key exists (if there is a :key)
 *
 *
 * **Model/Doc(instance) method signature**
 * 
 * function(options, cb){}
 * [this] in method refs the Model or Doc(instance)
 * 
 * options: {
 * 	opdata: req.body,
 * 	query: req.query
 * }
 *
 * cb(err, result)
 *
 * No req, res, next in method definition allowed!
 *
 * @author Tim.Liu
 * @created 2013.06.08
 */

module.exports = function(app){

	var urlbase = app.config.server.apiBase.logic;
	var pre = app.routes.filters.pre.api.logic;

	//statics - used per model or meta obj
	app.serve('general.logic.std.exec', 'all', urlbase + '/:model/:methodName', pre.guards.statics, function(req, res, next){

		req.target[req.params.methodName]({
			opdata: req.body,
			query: req.query,
			user: req.user
		}, function(err, result){
			if(err) res.json({error: err});
			else res.json({payload: result});
		})

	});

	//instance - used per doc
	app.serve('general.logic.std.exec', 'all', urlbase + '/:model/:key/:methodName', pre.guards.instance, function(req, res, next){

		req.doc[req.params.methodName]({
			opdata: req.body,
			query: req.query,
			user: req.user
		}, function(err, result){
			if(err) res.json({error: err});
			else res.json({payload: result});
		})

	});
	

};