/**
 * The static configuration to load before server startup.
 *
 * [IMPORTANT: all file paths are defined relative to this config file]
 *
 * @author Tim.Liu
 * @created 2013.05.09
 * @updated 2013.05.20 - for 1.0 server with express-load
 */

module.exports = {

	/**
	 * ==================
	 * Server
	 * ==================
	 */
	server: {
		port: '4000', //Default serving port will still be 3000 if left empty...
		clientPath: __dirname + '/../../' + 'Client_/implementation', //This is the web client project's web root...

		loglvl: 'dev',
		sessionCookieKey: 'web.sid',

		secret: {
			cookie: 'you will never know :P', //CHANGE THIS
			session: 'can not tell ya, sry :D' //CHANGE THIS
		},

		//Preset users are all of record space lvl of Void. (see /util/configpassport.js)
		//Warning: do Not change the preset usernames (keys) here, only the password. (see /routes/filters.js)
		users: {
			'superadmin': {
				password: '123#',
				account_space: 'System',
				_space: 'Void'
			},
			'guest': { //do Not change this unless you don't want to have middleware.auth.guestPassThrough enabled.
				password: '_',
				account_space: 'User',
				_space: 'System', //this is to make sure that this account can be assigned with roles created by superadmin.
				roles: ['Guest'] //put special preset role names here.
			}
		},

		/*Web API*/
		apiBase: {
			data: '/data',
			file: {
				upload: '/upload',
				download: '/download',
			},
			logic: '/logic',
		},

		middleware: { /*Enable/Disable middlewares with options*/
			auth: {
				guestPassThrough: true, //assume a default guest account if not logged in.
				whiteList: {
					'POST': {
						'/login': true
					},

					'GET': {
						'/tryscripts': true
					}
				}
			},
			//crossdomain: true,
			fileupload: {
				maxNumberOfFiles: 1,//if this is 0 or undefined, the maxUploadSize will be used, otherwise the maxUploadSize will be infered by this * maxFileSize
				maxFileSize: 5, //MB
				maxUploadSize: 10, //MB only affects the upload stream if the maxNumberOfFiles is 0 or undefined.
				types: [],
				typeFilter: 'banned' //either to use types as 'allowed' or 'banned' list to filter out the uploaded file types.
			},

			//offline: false - not in use yet;
			//error: false - not in use yet;
		},

		/*Supportive file containers*/
		support: {
			temp: __dirname + '/../temp',
			upload: __dirname + '/../upload',
		}		

	},


	/**
	 * ==================
	 * Database 
	 * ==================
	 */
	database: {

		mongodb: {
			host: 'localhost',
			port: '',
			username: '',
			password: '',
			name: 'Dev1_0',
			options: {

			}	
		},

		mysql: {

		},

		redis: {

		}
	},


	/**
	 * ========================
	 * Tools:
	 * Development helper tools (exposed as app routes and defined under /tools)
	 * [Make sure there is a web module folder with a enroll()]
	 * ========================
	 */
	tools: {
		//modelgen: true,
		lesswatch: {
			_dev: true
		}
	},



	/**
	 * =================
	 * Don't modify this
	 * =================
	 */
	_def_file: this
};