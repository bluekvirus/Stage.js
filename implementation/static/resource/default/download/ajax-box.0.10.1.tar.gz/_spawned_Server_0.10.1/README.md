Current Version
===============
0.10.0


RoadMap 1.0.0-pre
=================
Upgrading to Express 4.0.x, keep express-load module.
(better doc and usage scenarios, better structures)
0. Move the lesswatch tool out into client project's tools.
1. Need to refine the router/filter layer architecture.(cell[meta, model], links[triggers between cells] general routes, per model overriden, filters and links to replace the fixed 2-lvl only routes)
2. Refine/Simplify named route tokens, update Role's api access map (privilege_map) structure. 
3. Add support for CSRF tokens and Redis DB session.
4. Add cluster.
5. Add server admin(monitor, config and resources[switching to RethinkDB?]).
6. Give an introduction on how to use routing/filtering with model specific method hook on read/create/update/delete.
7. Give an introduction on how to wrap up 3rd party services(other than local db and file) using Meta Objects(instead of Model Objects)


System Requirement
==================
node v0.8.20+
[https://github.com/joyent/node/wiki] - release & api change.
[https://github.com/joyent/node/wiki/Installation] - installation.
[https://github.com/joyent/node/wiki/Installing-Node.js-via-package-manager] - installation via package managers.


Env Prep (Development)
======================
```
	node install -g nodemon
	npm install
	npm start (default: development mode)
```

Note that in a production environment it is better to use forever [https://github.com/nodejitsu/forever]


Ubuntu (Linux)
==============
Ubuntu package manager will name node.js to be nodejs instead of node, so you might need this line:

`[sudo] ln -s /usr/bin/nodejs /usr/bin/node`

Also you can find your nodejs by the `whereis ...` command.


Shutting Down
=============
[sudo] killall node/nodejs 
or
if using forever [https://github.com/nodejitsu/forever]
