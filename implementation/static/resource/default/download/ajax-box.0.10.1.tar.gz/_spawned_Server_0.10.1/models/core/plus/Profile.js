/**
 * This is the User.Profile model definition
 *
 * ==================
 * Enhancement Models
 * ==================
 * User's Profile and Preference enhancement models added and tested with population (read op only from data api routes);
 * By design, we will not support post/put or delete routes of one-to-one ref docs, it is designed to be manipulated through exposed logic routes.
 * The one-to-one ref model acts as a parent model's enhancement.
 * Note that if a model appears in another model's schema as a one-to-one ref, it is marked as a enhancement model (in the def meta) and thus won't appear in the 'resource list' (see - meta_objects/Resources.js) as stand alone nor refed fields.
 * Enhanced parent model is in charge of providing logic apis for manipulating the data parts.
 * Mutex should be applied and manipulation of the enhanced data parts should be treated as parent's data in all situations.
 *
 * An 'enhance' flag will be added to the model def later by util/modelrelationship.js, identifying which model(s) has been enhanced by this one.
 * 
 * @author Tim.Liu
 * @created 2013.10.10
 */
var mongoose = require('mongoose');

module.exports = function(app){

    var Profile = app.util.objectfactory.create('Profile', {

        schema: {
            name: {
                type: String
            },
            birthday: {
                type: Date
            },
            //...Add your profile related fields here.
        },

        imposeOwnerSpace: true,
        mutex: 'private',
        srcLocation: this.location
    });

    return Profile;

}