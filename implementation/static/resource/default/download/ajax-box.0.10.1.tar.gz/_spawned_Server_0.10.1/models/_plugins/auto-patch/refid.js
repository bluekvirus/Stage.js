/**
 * This plugin helps to add the parent id field to schema if 
 * meta.refBy has other models registered as possible parent model(s).
 *
 * @author Tim.Liu
 * @created 2013.06.18
 */

var _ = require('underscore');

module.exports = function(app){

	return function(schema, options){
		
		var refBy = options.definition.meta.refBy;
		if(!refBy) return;

		_.each(refBy, function(refInfo, modelName){
			var refIdFieldDef = {};
			refIdFieldDef[refInfo.link] = {type: 'objectId', ref: modelName};
			schema.add(refIdFieldDef);
		});

	}

};