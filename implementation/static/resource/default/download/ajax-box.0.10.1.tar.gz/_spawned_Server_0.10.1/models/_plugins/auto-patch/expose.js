/**
 * Logic (Schema static/method) expose plugin
 *
 * schema.expose(methodName, type, fn){
 * 
 * }
 * fn(options, cb)
 * options:{
 * 	opdata: req.body
 * 	query: req.query
 * }
 * cb(err, result)
 *
 * This also exposes the fn name to Model Definition's restriction.logic
 * so that it will further be examined in a filter guard for logic api.
 * 
 * @author Tim.Liu
 * @created 2013.06.15
 * 
 */

module.exports = function(app){

	return function(schema, options){

		schema.expose = function(name, type, fn){
			
			if(!fn) {
				fn = type;
				type = 'static';
			}

			switch(type){
				case 'static':
					schema.static(name, fn);
					options.definition.restriction.logic[name] = type;
				break;
				case 'instance':
					schema.method(name, fn);
					options.definition.restriction.logic[name] = type;				
				break;

				default:
				break;
			}
		}

	}

}