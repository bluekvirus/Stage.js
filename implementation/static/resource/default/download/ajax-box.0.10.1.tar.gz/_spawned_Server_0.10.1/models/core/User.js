/**
 * This is the User model
 *
 * Note that a hash and salt field will be added by passport-local-mongoose plugin later in User.ext.js under /models/_plugins/selective-patch.
 *
 * ======================
 * Account & Record Space
 * ======================
 * Since we use Roles to control RESTful api access for a user, there needs to be another way that built on top of the role (token group) based access control for data controls within the same role.
 * Thus, like the Linux OS, we will have three(kernel/sudoer/user) spaces for the users to use the privilege_map calculated from user's roles differently. They are:
 *     Void (lvl 3) - this is the outter space :P. 
 *     System (lvl 2) - 
 *                     users in this space controls everything, bypassing the authorization layer; 
 *                     records in this space can not be modified or seen by users below this lvl, even he/she has the same api access map (privilege_map); 
 *     Administrator (lvl 1) - 
 *                     from this level up the mutex meta option set on Model definitions will not affect the api access control in data routes. 
 *                     however, the _space field of the record is consulted and compared with the user's account space before update/deletion operation.
 *     User (lvl 0) (default) - 
 *                     the mutex meta option set on Models will be consulted before serving the data routes. see - routes/filters.js mutex().
 *
 * **Basic Security Rules**
 * 1. A user's account_space(string) defines what it can see and modify; If a user has account_space:Administrator, we say that it 'exists' in the Administrator space.
 *    A record's _space(number) level determines which space and above contains its valid viewer. 
 * 2. A user can only see/modify the records that are <= its account space level.
 * 3. If a Model's metadata says 'imposeOwnerSpace', all the records created by a user will have their _space(number) assigned to be the user's account_space(string) level. 
 * 4. A user that exists in the 'User' space will have to conform to additional 'mutex' settings from Models when accessing/modifying their instances. - see auto-patch/mutex.js
 * 5. A record's valid modifier (owner, collaborator, admin) will have full power over the sub table docs (ref-ed docs) regardless of the sub table doc's Model mutex meta setting.
 *
 * **Together with Roles and Resources**
 * Roles and Resources listings are two important objects that help ensure application security.
 * 1. Roles are groups of resource access tokens, since we use named routes, the tokens will be mapped directly to data/file/logic routes. see - util/namedroutes.js
 * 2. Resources is a meta object that organizes the general access tokens and output them per Model/Meta object. see meta_objects/Resources.js
 * 3. A Role record's _space determines what kinda user records it can attach to, a role record can NOT be assigned to a user record with lower _space lvl.
 *    This is to make sure that a user with the User and Role access tokens can NOT assign with its users (created by it) some higher level access to the resources by guessing Role names.
 *
 * **Bring the privilege system to live**
 * Order of creation: Void -> +super admin -> + admin -> + users
 *                              [System]   [Administrator] [User]
 * 1. A user with User access token can ONLY create users with 1+ account_space level lower than itself.
 * 2. Roles and Resources access tokens will not be available to the Administrator (and of course User) space level users.
 * 3. Users modifying a record will not change its _owner and _space level. Only upon creation.
 * 4. Administrators can choose to escalate or downgrade a record's space so it can be viewed by users from certain level, not that, if the record is downgraded to the 'User' space, mutex settings applies.
 * 5. Administrators can choose to change the _owner of a record, but this will also reset the _space level of that record.
 * 
 *
 * @author Tim.Liu
 * @created 2013.10.10
 */

var mongoose = require('mongoose'),
_ = require('underscore');

module.exports = function(app){

    //+Account Space Scale to global config
    app.config.spaceScale = {
        'Void': 3, //No user should exist in this lvl, only pre-defined records. (e.g the Super Admin user record)
        'System': 2, //Super Admin's account_space is in this lvl
        'Administrator': 1,
        'User': 0
    };
    app.config.spaceArray = _.keys(app.config.spaceScale).reverse();

    var User = app.util.objectfactory.create('User', {

        schema: {
            //required.
            username: {
                type: String,
                unique: true
            },
            password: {
                type: String,
                hideInJSON: true
            },
            account_space: { 
                //another _space field is added to every data record by the mutex patch to override the _owner's account_space imposed on the record.
                //see - /models/_plugins/auto-patch/mutex.js
                type: String,
                default: 'User'
            },

            //plus.
            roles: {
                type: [String] //data API access control, to be used together with account/record spaces
            },
            profile: {
                ref: 'Profile' //additional user info
            },
            preference: {
                ref: 'Preference' //app pref of this user
            }            
        },

        imposeOwnerSpace: true,
        srcLocation: this.location
    });

    return User;

}