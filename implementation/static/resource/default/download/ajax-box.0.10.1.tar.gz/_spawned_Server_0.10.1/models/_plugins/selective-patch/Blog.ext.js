/**
 * Example/Test.
 */

module.exports = function(app){

	return function(extSchema, options){

		extSchema.expose('testi', 'instance', function(options, cb){
			//
			var result = options
			cb(null, result);
		});

		extSchema.expose('tests', function(options, cb){

			var result = options
			cb(null, result);
		});

		extSchema.expose('err', function(options, cb){

			cb('error!');
		});


	};

};