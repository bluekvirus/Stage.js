/**
 * General model schema plugin for data validation, using model module definition.validation settings
 *
 * @author Tim.Liu
 * @created 2013.06.03
 */

var backbone = require('backbone'),
	validation = require('backbone-validation'),
	_ = require('underscore');

_.extend(backbone.Model.prototype, validation.mixin);

module.exports = function(app){

	/**
	 * [ description]
	 * @param  {[type]} schema  [description]
	 * @param  {[type]} options {definition: model module definition}
	 * @return {[type]}         [description]
	 */
	return function(schema, options){

		//Don't need additional closure...
		//return (function(){
			var validation = options.definition.restriction.data;
			var vModel = backbone.Model.extend({
				validation: validation
			});

			//hook up the validation to schema middleware.
			schema.pre('save', function(next){
				var val = new vModel(this.toJSON());

				var error = val.validate();
				if(error)
					next(new Error(JSON.stringify(error)));
				else
					next();
			});

		//})();

	};

}