/**
 * This is the User.Role model definition
 *
 * @author Tim.Liu
 * @created 2013.10.10
 */
var mongoose = require('mongoose');

module.exports = function(app){

    var Role = app.util.objectfactory.create('Role', {

        schema: {
            name: {
                type: String
            },
            description: {
                type: String
            },
            privileges: {
                type: mongoose.Schema.Types.Mixed //calculated according to data APIs - see util/namedroutes.js and routes/
            }
        },

        imposeOwnerSpace: true,
        srcLocation: this.location
    });

    return Role;

}