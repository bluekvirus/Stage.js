/**
 * General model schema plugin for adding timestamps
 *
 * Using mongoose-times -[https://github.com/nicholasconfer/mongoose-times]
 *
 * @author Tim.Liu
 * @created 2013.06.03
 */


var timestamps = require('mongoose-times');

module.exports = function(app){

	return function(schema, options){

		schema.plugin(timestamps, {
	        created: "created_at",
	        lastUpdated: "updated_at"
    	});

	}

}