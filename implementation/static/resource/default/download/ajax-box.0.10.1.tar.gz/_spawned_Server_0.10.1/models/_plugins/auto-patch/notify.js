/**
 * Notify changes about this model's record to related watchers
 *
 * Schema Plus (+ _watcher [])
 *
 * @author Tim.Liu
 * @created
 */

module.exports = function(app){
	//TBI
	return function(schema, options){

	};
}
