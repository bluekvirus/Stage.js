/**
 * This is the Role model extension for automatically
 * re-calculate affected user privilege map in 'post save'
 *
 * @author Tim.Liu
 * @created 2013.04.27
 * @updated 2013.05.21
 * 
 */

var mongoose = require('mongoose'),
    backbone = require('backbone'),
    _ = require('underscore');

module.exports = function(app){

	function updateUserPrivilegeMap(roleName){
		//Find the users that has 'role' in his/her roles array...
		//Note that the {roles: role} means roles array has value role.
		//can use $all(and) and $in(or) and $ne(not in) for other conditions...		
		app.getModel('User').find({roles: roleName}, function(err, users){
			if(err) console.log('Cant update related users...', err);
			else
				_.each(users, function(user){
					//update users privilege map here
					console.log('Updating User...', user.username);
					user.calculatePrivilegeMap();
					//logout user?
					//...
				});
		});
	};

	return function(extSchema, options){

		if(!extSchema){
			console.error('Patching Role model error...');
			return;
		}

		/**
		 * =====================
		 * Modify User.Schema
		 * .set - options (hideInJSON, hideInObject...)
		 * .add - field
		 * .plugin - plugin
		 * .pre/.post - pre/post hook
		 * .static - method
		 * .method - instance method
		 * =====================
		 */
		
		extSchema.pre('save', function(next){
			//we need to check if this Role record contains privileges that can not be assigned by the creator (indicated by _space)
			//like in the Resources (meta obj) listing function, the most concerning privilege objects are 'Role' and 'Resources'
			//if this Role record's space is below the 'System' level, then it should not be assigned with these.
			//(since the client's UI will not receive them as resource control items, see - meta_objects/Resources.js)
			var recordspacelvl = this._space || 0;
			if(recordspacelvl < app.config.spaceScale['System']){
				_.each(['Role', 'Resources'], function(obj){
					delete this.privileges[obj];
				}, this);
			}
			next();
		});

		extSchema.post('save', function(role){
			console.log('Role::',role.name, ' changed...');
			updateUserPrivilegeMap(role.name);
		});

		//DO NOT use instance method here, since the document is removed. //see routes/filters.js - afterRemovalExtensionHook
		extSchema.static('post_remove', function(role){
			console.log('Role::',role.name, ' removed...');
			updateUserPrivilegeMap(role.name);
		});

	}	

};


