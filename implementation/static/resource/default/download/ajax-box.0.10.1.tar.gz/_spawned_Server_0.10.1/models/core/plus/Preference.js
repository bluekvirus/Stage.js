/**
 * This is the User.Preference model definition
 *
 * @author Tim.Liu
 * @created 2013.10.10
 */
var mongoose = require('mongoose');

module.exports = function(app){

    var Preference = app.util.objectfactory.create('Preference', {

        schema: {
            locale: {
                type: String
            },
            theme: {
                type: String
            },
            //...Add your application preferences related fields here.
        },

        imposeOwnerSpace: true,
        mutex: 'private',
        srcLocation: this.location
    });

    return Preference;

}