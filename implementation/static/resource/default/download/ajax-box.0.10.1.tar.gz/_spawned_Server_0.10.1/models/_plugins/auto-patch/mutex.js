/**
 * This is the 'User Space' mutual exclusion support extension to all the models.
 * Note that if the user account is in the 'Administrator Space' and above, the mutex settings on the model will be skipped.
 * - see explaination on account spaces in models/core/User.js
 * 
 * Schema Plus (+ _owner, + _collaborator [], + _space)
 * 
 * The mutex meta option will control the access/edit of this type of documents.
 * 		- mutex is 'private' -> Only the _owner and _collaborators can read and modify this doc instance, others can not read/modify it.
 * 		- mutex is 'read-only' -> Only the _owner and those in the _collaborator array can modify it. Those have the role but not in the array can only read it.
 * 		- mutex is 'disabled' -> The _owner/_collaborator array will not be checked, but anyone with the right role privilege can modify the documents.
 * 						
 * ------------------------------------------------------------------------
 * This ability will be utilized in filters defined in  /routes/filters.js
 * ------------------------------------------------------------------------
 * 
 * @author Tim.Liu
 * @created 2013.06.03
 */

module.exports = function(app){

	return function(schema, options){

		schema.add({
			_owner: 'string',
			_collaborators: ['string'],
			_space: {
				type: 'number', 
				default: 0, //see the scale settings in /model/core/User.js
				//this is there to override the _owner's account_space imposed on the record so that a data record can be seen (if not modified) by lower space lvl users;
				//users with the same role but higher space lvl can choose to escalate it;
				//users can only read/modify records with equal and lower space level given their account_space level.
			}
		});

	};

};