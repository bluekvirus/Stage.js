/**
 *
 * Plugin code for user authentication and authorization
 *
 * Used with the 'User' model. 
 *
 * Note that a {} is true in if() on V8 js engine...
 *
 * @author Tim.Liu
 * @create 2013.04.14
 * @update 2013.04.14
 */

var mongoose = require('mongoose'),
_ = require('underscore'),
strategy = require('passport-local-mongoose'),
json = require('json3');

module.exports = function(app){

	return function(extSchema, options){

		if(!extSchema){
			console.error('Patching User model error...');
			return;
		}
		

		/**
		 * =====================
		 * Modify User.Schema
		 * .set - options (hideInJSON, hideInObject...)
		 * .add - field
		 * .plugin - plugin
		 * .pre/.post - pre/post hook
		 * .static - method
		 * .method - instance method
		 * =====================
		 */

		extSchema.add({
			privilege_map: {
				type: mongoose.Schema.Types.Mixed,
				hideInJSON: true,
			},
		});

		/**
		 *  Options
		 *  When plugging in Passport-Local Mongoose plugin additional options can be provided to configure the hashing algorithm.

		 *  User.plugin(passportLocalMongoose, options);

		 *	Option keys and defaults

			    saltlen: specifies the salt length in bytes. Default: 32
			    iterations: specifies the number of iterations used in pbkdf2 hashing algorithm. Default: 25000
			    keylen: specifies the length in byte of the generated key. Default: 512
			    usernameField: specifies the field name that holds the username. Defaults to 'username'. This option can be used if you want to use a different field to hold the username for example "email".
			    saltField: specifies the field name that holds the salt value. Defaults to 'salt'.
			    hashField: specifies the field name that holds the password hash value. Defaults to 'hash'.

		 *	Attention! Changing these values for example in a production environment will prevent that existing users can authenticate!
			
		 *	Hash Algorithm
		 *  Passport-Local Mongoose use the pbkdf2 algorithm of the node crypto library. Pbkdf2 was choosen because platform independent (in contrary to bcrypt). For every user a generated salt value is saved to make rainbow table attacks even harder.

		*/
		var plmOptions = {
			usernameField: 'username',
			saltField: 'salt',
			hashField: 'hash',
		};
		extSchema.plugin(strategy, plmOptions);
		extSchema.set('hideInJSON', ['hash', 'salt']);

		//Add in a pre('save') hook to check the account_space assigned. 
		//It should NOT be higher than the user account record's space so that the 'creator' can NOT escalate himself by creating another user account.
		//Note that by setting this check, admins that are in a higher level space must first escalate the record's space before he/she can escalate the account space of a user.
		extSchema.pre('save', function(next){
			this.password = this.password || '.';
			this.account_space = app.config.spaceScale[this.account_space] === undefined? 'User' : this.account_space;
			if(app.config.spaceScale[this.account_space] >= this._space) 
				//we downgrade the account_space lvl to be 1 lvl lower of the creator
				this.account_space = app.config.spaceArray[this._space - 1] || 'User';
			next();
		});

		//Add in a post('save') hook to ACTUALLY register the user using Passport.
		//Note that we need to delete the user password after registering.
		extSchema.post('save', function(){
			if(this.password){
				this.setPassword(this.password, function(err, user){
					user.set('password', '');
					user.update({$set: {hash: user[plmOptions.hashField], salt: user[plmOptions.saltField]}},function(err){
						if(err) console.log('Cant set password & salt', err);
					}); //This will not trigger 'save' event
				})
			}
			//calculate the privilege hash from role
			this.calculatePrivilegeMap();

		});		


		//Overridden strategy's serializeUser
		//We define the keys that should be stored in req.session.passport.user
		extSchema.static('serializeUser', function(){
		    return function(user, cb) {
		    	//get account space and privilegeMap out ready for filters.
		        cb(null, {name: user[plmOptions.usernameField], privilegeMap: user.privilege_map, space: user.account_space});
		    }
		});

		/**
		 * **Security**
		 * Note that if roles of the same user overlap, privilege settings for the same data/meta object
		 * will be from the 'top' role in the role list.
		 *
		 * Also we will delete roles from role name array if they can not be found in database.
		 *
		 * Also we filter out the roles that are above the space lvl of this user's creator.
		 * @return {[type]} [description]
		 */
		extSchema.method('calculatePrivilegeMap', function(){
			var roleNames = this.roles.reverse();//to counter the order-of-effect in _.extend();
			var rolePrecedence = {};
			roleNames.map(function(role, index){
				rolePrecedence[role] = index;	
			});
			app.getModel('Role').where('name').in(roleNames).where('_space').lte(this._space).select('name privileges').find(_.bind(function(err, roles){
				//check first
				if(_.size(rolePrecedence) > 0 && roles.length <= 0) {
					console.log(new Error('Roles => :' + _.keys(rolePrecedence).join(':') + ': are above space \'' + app.config.spaceArray[this._space] + '\', or doesnt exist for user ' + this.username).toString().yellow);
					return;
				} 

				//sort roles
				roles = _.sortBy(roles, function(role){
					return rolePrecedence[role.name];	
				});
				var privilege_map = {};
				//mix them, overlap - see method comment.
				_.each(roles, function(role){
					_.extend(privilege_map, role.privileges);
				});
				//save
				this.update({privilege_map: privilege_map, roles: _.pluck(roles, 'name').reverse()}, _.bind(function(err, noa){
					if(err) console.log(err);
					else console.log('User', this.username, ':privileges updated...', noa);
				}, this));
			}, this));
		});

	};

};



