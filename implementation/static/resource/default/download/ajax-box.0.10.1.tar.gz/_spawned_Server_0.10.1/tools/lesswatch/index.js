/**
 * This is the client theme less file monitoring tool which automatically detects and compiles the less file with changes.
 * config is set in the config.js which should have the following format:
 * 
 * tools: {
 * 		...,
 * 		lesswatch: true | false
 * 		...,
 * }
 *
 * ===========
 * Assumptions
 * ===========
 * 1. the main less file should be main.less
 * 2. the dist css will be main.css
 *
 * @author Tim.Liu
 * @created 2013.10.27
 */

var _ = require('underscore'),
path = require('path'),
fs = require('fs'),
filed = require('filed'),
watch = require('watch'),
less = require('less'),
colors = require('colors'),
autoprefixer = require('autoprefixer'),
cleancss = new (require('clean-css'))({keepSpecialComments: 0});

_.str = require('underscore.string');

module.exports = function(app){
	if(!app.config.tools.lesswatch)
		return;

	// watch the client themes folder
	var themes = path.resolve(path.join(app.config.server.clientPath, 'themes'));
	function recompileTheme(f, root){
		if(path.extname(f) !== '.less') return;

		var lessDir = path.join(root, 'less');
		var mainLess = path.join(lessDir, 'main.less');
		var parser = new(less.Parser)({
			paths: ['.', lessDir]
		});
		console.log('[Theme changed:'.yellow, f, ']'.yellow);
		fs.readFile(mainLess, {encoding: 'utf-8'}, function (err, data) {
			if (err) throw err;
			parser.parse(String(data), function(e, tree){
				if(e) return console.log('LESS Parser Error'.red, e);
				var mainCss = path.resolve(path.join(mainLess, '../../', 'css', 'main.css'));
				var mainCssFile = filed(mainCss);
				//use autoprefixer(options).compile if needs be in the future.
				var css = autoprefixer(/*options*/).process(tree.toCSS()).css;
				css = cleancss.minify(css);
				mainCssFile.write(css);
				mainCssFile.end();
				console.log('[Theme recompiled:'.yellow, mainCss.cyan, ']'.yellow);				
			});
		});

	};

	fs.readdir(themes, function(err, list){
		if(err) throw err;
		_.each(list, function(theme){
			//monitor only the selected theme(s) in config.
			if(app.config.tools.lesswatch[theme]){
				var root = path.join(themes, theme);
				watch.createMonitor(root, {
					ignoreDotFiles: true
				}, function(monitor){
					// monitor.on("created", function (f, stat) {
					// });
					monitor.on("changed", function (f, curr, prev) {
					  recompileTheme(f, root);
					});
					// monitor.on("removed", function (f, stat) {
					// });
					console.log(('[Theme ' + theme + ': .less files monitored]').yellow, '-', ('lessjs v' + less.version.join('.')).grey);
					return monitor;
				});
			}
		});
	});

}