/**
 * This is the tool that generates/manages the server models during app development. 
 * It takes developer's POST/PUT/DELETE and GET requests and does the following:
 *
 * POST(dev/:model): creates a new server model and put it under /models/resource/
 * PUT: it creates and replaces the model under /models/resource/
 * DELETE: it removes the model under /models/resource/
 *
 * GET: it returns all the models that are now under /models/resource/ and info from the database about them.
 *
 * @author Tim.Liu
 * @created 2013.09.28
 */

var _ = require('underscore'),
buildify = require('buildify'),
hb = require('handlebars'),
js_beautify = require('jsbeautify/beautify').js_beautify;
_.str = require('underscore.string');

//Preprocess ref/sub to another model or [] through a '^' string in UI.
hb.registerHelper('getORMSchemaType', function(key, type){
	type = _.str.trim(_.unescape(type));
	if(type.match(/^\^/)){
		//must be sub doc(s) -- sub: '...'
		return 'sub: ' + type.substr(1);
	}else if(type.match(/\'/)){
		//must be ref doc(s) -- ref: '...'
		return 'ref: ' + type;
	}else
		return 'type: ' + type;
});

module.exports = function(app){

	if(!app.config.tools.modelgen)
		return;

	var apiBase = '/dev/models/';

	//POST
	app.post(apiBase, function(req, res){
		var model = req.body;
		//1. check model.name, if exists report error back
		if(app.getModelDef(model.name))
			res.json(500, {error: 'There is already a ' + model.name + ' model on server'});
		//2. pass the model to buildify and Handlebars to produce model file under
		else {
			buildify()
				.setDir(__dirname)
				.load('model.tpl').perform(function(content){
					var code = hb.compile(content);
					content = js_beautify(code(_.extend(model, {date: new Date()})));
					return content;
				})
				.setDir('models')
				.save('uncategorized/' + model.name + '.js');
			res.json({success: true, msg: 'Your model has been created ->' + model.name});
		}
	});

	//PUT - skipped.
	// app.put(apiBase, function(req, res){

	// });

	//DELETE - skipped.
	// app.delete(apiBase, function(req, res){

	// });

	//GET all mapping
	app.get(apiBase, function(req, res){
		res.json(app.util.modelmap.getMap());
	});

	//GET single def
	app.get(apiBase + ':model', function(req, res){
		var result = app.getModelDef(req.params.model) || {error: 'Resource Model Not Found...'};
		res.json(result);
	});



}