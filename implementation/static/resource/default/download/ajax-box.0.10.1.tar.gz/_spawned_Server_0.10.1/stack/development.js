/**
 * The server middleware stack definition
 *
 * @author Tim.Liu
 * @created 2013.05.20
 */

var express = require('express'),
error = require('express-error'),
colors = require('colors');

exports.setup = function(app){

  /**
   * Static/Gzip layer as early as possible
   */
  app.use(express.static(app.config.server.clientPath));
  app.use(app.middleware.crossdomain);
  //app.use(express.favicon());
  app.use(express.logger(app.config.server.loglvl));
  /**
   * Form/URL/Header data 
   */
  app.use(express.json());
  app.use(express.urlencoded());
  //we user our own file upload middleware instead of connect.multipart. - delayed to be in filters.js
  app.use(express.cookieParser(app.config.server.secret.cookie)); 
  /**
   * Authentication/Authorization and Session (store will be redis in production)
   */
  app.use(express.session({secret: app.config.server.secret.session, key: app.config.sessionCookieKey, /*store: */}));
  app.use(app.util.configpassport.getInstance().initialize());
  //app.use(passport.session());//This will conflict with fileupload.[?formidable?] since it goes to IO (db) to fetch user.
  app.use(express.methodOverride());
  
  /**
   * CSRF related... (completely ban non-ajax post/put/delete or you need a CSRF token in each form)
   * app.use(function(req, res, next){
   *   if(!req.xhr && req.method !== 'GET')
   *     throw new Error('Non-Ajax POST Rejected');
   *   next();
   * });
   */
  
  app.use(app.middleware.auth);       
  app.use(app.router);
  /**
   * Error handling & reporting
   */
  app.use(error.express3({contextLinesCount: 3, handleUncaughtException: true}));
};