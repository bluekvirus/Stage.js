/**
 * The server middleware stack definition
 *
 * @author Tim.Liu
 * @created 2013.06.07
 */

var express = require('express'),
error = require('../middleware/error'),
auth = require('../middleware/auth');

exports.setup = function(app){


  /**
   * Error handling & reporting
   */
  app.use(error._404());
  app.use(error._500({handleUncaughtException: true}));

};