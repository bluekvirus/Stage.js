ProJS.Client
=============
An infrastructure for building modern web application with many contexts.


Current Version
---------------
1.0.0-rc1


Quick Start
-----------
###What's in the package

###Mental preparation

###Development steps

###When it comes down to create a View

###Create a new theme



Include other js libs
---------------------
The default all.js contains selected libs for the project, if you would like to introduce more use `bower` and the `bower.json` file included.
Append/Include your libs after all.js.


Build for production use
------------------------
Use `/tools/build` you need to check the config file though. **NOT INCLUDED ATM**


Upgrade/Update
--------------
Download and replace `js/all.js` to update the infrastructure;
Use `bower update` to update other monitored libs you need;


Appendix
--------
###A. Philosophy behind
see PHILOSOPHY.md

###B. Change log
see CHANGELOG.md